# DU-World Moniter R29 — Immersive Local Monitors

R29 preserves the R28 globe, public-source desk, replay, analysis, eight live-motion widgets and
Local Monitor data. It rebuilds the report viewer around an edge-to-edge native story surface.

## Report viewing

- A native `TextureView` player now owns the full screen. **FILL** uses centre crop and **FIT**
  reveals the complete source frame, removing the permanent black action column seen in R28.
- Swipe up/down changes reports with motion; tap pauses, double-tap likes, and press-and-hold
  temporarily mutes.
- Story progress bars, automatic advance, compact collapsible filters and over-video source state
  keep the video dominant without hiding credibility.
- Profile, like, comment and share actions float over the video. Comments open in a native
  bottom panel instead of replacing the report screen.

## Reporting and identity

- Reporters can select 15-second, 30-second, 60-second, three-minute or five-minute camera limits.
- The composer adds a headline, approximate-location protection and explicit draft/discard paths.
- Private drafts can be reopened; discarding removes the private video only after confirmation.
- A real profile photo can be selected and stored privately on the phone. HTTPS `avatar_url`
  images returned by a connected service are loaded with a strict 2 MiB limit and cached locally.

## Upload continuity and globe link

- R29 supports resumable, offset-based upload sessions when the connected service implements the
  R29 API. Progress and resume offsets are persisted while the original local video remains safe.
- Services that expose only the R28 multipart endpoint continue to work through a compatibility
  fallback, but those fallback transfers restart after interruption.
- Coordinate-bearing reports—and reports whose stated place matches the app's built-in centroid
  index—appear as clearly labelled MEDIA markers on the main globe. Inferred markers are labelled
  approximate. Tapping one opens that exact report; private drafts never become markers.

## Truth and network boundaries

Every new public report still begins as **UNVERIFIED**. Profile photos, badges, follows, likes,
comments and popularity never confirm a report. **REPORTED** and **CONFIRMED** remain distinct
server-supplied credibility states.

Without a configured public HTTPS Monitor Network, videos, drafts, likes and comments remain on
the phone and are never presented as cross-device, synced or live. True multi-user distribution,
moderation and live publishing still require a service implementing `LOCAL_MONITORS_API.md`.
