# R28 — Local Monitors

R28 adds a native, vertical location-video reporting desk while preserving the R27 globe, live
provider sources, replay, analysis pages and all eight home-screen widgets.

## Visible additions

- **MONITORS** is the second action in the globe mission dock and a first-class intelligence page.
- Reporter profiles include display name, handle, home location and short bio.
- Record a video with the phone camera or import an existing video.
- Composer requires a caption, stated location, recording rights and safety confirmation.
- Optional coarse/fine coordinates attach only after explicit Android permission.
- Story reports expire after 24 hours; persistent reports remain until deleted.
- Full-screen vertical video feed supports swipe navigation and source/status overlays.
- Profile/story rail, LIVE, FOR YOU, NEARBY and FOLLOWING views.
- Likes, comments, shares, follows, blocking and harmful/misleading-content reports.
- Native playback for local MP4 and server-returned HTTPS video/live streams.
- Offline local outbox protects the reporter's video when upload fails.
- Network connection and live tokens are encrypted using Android Keystore.

## Truth and safety contract

- Every new public report begins as **UNVERIFIED**.
- Profile verification is displayed separately from report credibility.
- Likes, comments and viewer counts never change credibility.
- A report is never labelled LIVE unless the configured service creates a live session.
- No sample people, fabricated engagement or invented community reports are bundled.
- Cross-device exchange requires the documented HTTPS Local Monitors API.
- No WebView and no external Android runtime library were introduced.

