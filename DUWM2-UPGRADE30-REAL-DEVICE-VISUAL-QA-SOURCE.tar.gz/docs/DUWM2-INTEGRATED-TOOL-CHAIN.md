# DUWM2 integrated tool chain
Chronology:
Launch/Globe -> System rail or object -> Source Index -> Search/Filter -> Record Detail ->
Source OR Map OR Follow -> Related Intelligence -> Share Studio.
Monitors: Globe/Monitor -> Monitor Hub -> Report/Profile/Media/Location -> Detail -> Comment/Follow -> Share/Map.
Offline: Any unavailable state -> Offline Cache -> retained state -> Retry Sources -> Source Index.
Deep links/widgets: duwm://open -> system/record -> same Record Detail -> same downstream actions.
Every handoff carries system/record context where available. No tool should silently route to an unrelated globe screen.
