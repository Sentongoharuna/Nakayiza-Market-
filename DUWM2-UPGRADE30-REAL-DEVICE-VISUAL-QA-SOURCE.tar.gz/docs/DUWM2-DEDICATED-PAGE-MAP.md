GLOBE/MAP -> geographic globe only.
NEWS/WIRE/BRIEF/RISK/ANALYST/FUSION/EVENTS -> dedicated Intelligence page.
AIR/AIRSPACE/SEA/WX/AIRWX/ORBIT/INFRA -> dedicated World System page with domain-specific purpose.
AIRPORTS/PORTS/MARKETS -> dedicated Transport/Market page.
RADIO/TV/CAM -> dedicated Media page.
MONITORS -> Monitor Hub. SOURCES -> Source Health. WIDGETS -> Widgets. WALLPAPER -> Wallpaper.
Each page has function-specific presentation and downstream detail/index/map/share actions.
