package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.widget.*;
public final class DuRefreshController{
 final Activity a; final String sys; final Handler h=new Handler(Looper.getMainLooper());
 final Runnable tick; TextView view;
 public DuRefreshController(Activity a,String s,TextView v){
  this.a=a;sys=s;view=v;
  tick=new Runnable(){public void run(){DuFreshness.mark(DuRefreshController.this.a,sys);render();h.postDelayed(this,60000);}};
 }
 public void start(){h.removeCallbacks(tick);tick.run();}
 public void stop(){h.removeCallbacks(tick);}
 void render(){if(view!=null)view.setText("● "+DuFreshness.health(a,sys)+" · "+DuFreshness.label(a,sys));}
}