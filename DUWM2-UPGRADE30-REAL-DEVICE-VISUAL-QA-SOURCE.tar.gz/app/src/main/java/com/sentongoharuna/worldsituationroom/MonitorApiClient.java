package com.sentongoharuna.worldsituationroom;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HttpsURLConnection;

/**
 * Dependency-free HTTPS adapter for a user-controlled Local Monitor service.
 * The client never treats an absent server, failed upload or malformed response as published.
 */
public final class MonitorApiClient {
    private static final int CONNECT_TIMEOUT_MS = 10_000;
    private static final int READ_TIMEOUT_MS = 30_000;
    private static final int MAX_JSON_BYTES = 4 * 1024 * 1024;
    private static final int DEFAULT_UPLOAD_CHUNK = 1024 * 1024;

    private final MonitorProfileStore profiles;
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile HttpsURLConnection activeConnection;
    private volatile boolean shutdown;

    public MonitorApiClient(MonitorProfileStore profiles) {
        this.profiles = profiles;
    }

    public void loadFeed(String filter, String region, FeedCallback callback) {
        if (!profiles.networkConfigured()) {
            postToMain(() -> callback.onResult(new ArrayList<>(),
                    "Monitor Network not connected; showing reports stored on this phone"));
            return;
        }
        executor.execute(() -> {
            try {
                String endpoint = profiles.apiBase() + "/v1/reports?limit=40&filter="
                        + encode(normalFilter(filter)) + "&region=" + encode(safe(region, 80));
                Response response = request("GET", endpoint, null);
                List<MonitorReport> reports = MonitorReport.listFromJson(response.body);
                postToMain(() -> callback.onResult(reports, ""));
            } catch (Exception error) {
                postToMain(() -> callback.onResult(new ArrayList<>(), message(error)));
            }
        });
    }

    public void loadComments(String reportId, CommentsCallback callback) {
        if (!profiles.networkConfigured()) {
            postToMain(() -> callback.onResult(new ArrayList<>(), ""));
            return;
        }
        executor.execute(() -> {
            try {
                Response response = request("GET", profiles.apiBase() + "/v1/reports/"
                        + encodePath(reportId) + "/comments?limit=100", null);
                Object root = new org.json.JSONTokener(response.body).nextValue();
                JSONArray values = root instanceof JSONArray ? (JSONArray) root
                        : ((JSONObject) root).optJSONArray("comments");
                List<MonitorReport.Comment> comments = new ArrayList<>();
                if (values != null) {
                    int limit = Math.min(values.length(), 100);
                    for (int index = 0; index < limit; index++) {
                        JSONObject value = values.optJSONObject(index);
                        if (value != null) comments.add(MonitorReport.Comment.fromJson(value));
                    }
                }
                postToMain(() -> callback.onResult(comments, ""));
            } catch (Exception error) {
                postToMain(() -> callback.onResult(new ArrayList<>(), message(error)));
            }
        });
    }

    public void uploadReport(MonitorReport report, File video, UploadCallback callback) {
        if (!profiles.networkConfigured()) {
            postToMain(() -> callback.onResult(null,
                    "Connect a secure Monitor Network endpoint before publishing across phones"));
            return;
        }
        if (video == null || !video.isFile() || video.length() < 1_024L) {
            postToMain(() -> callback.onResult(null, "The local report video is unavailable"));
            return;
        }
        executor.execute(() -> {
            try {
                MonitorReport published;
                try {
                    published = uploadResumable(report, video, callback);
                } catch (ResumableUnavailable unavailable) {
                    report.uploadSessionId = "";
                    report.uploadOffset = 0L;
                    report.uploadTotal = video.length();
                    published = uploadMultipart(report, video, callback);
                }
                MonitorReport completed = published;
                postToMain(() -> callback.onResult(completed, ""));
            } catch (Exception error) {
                postToMain(() -> callback.onResult(null, message(error)));
            }
        });
    }

    private MonitorReport uploadResumable(
            MonitorReport report,
            File video,
            UploadCallback callback) throws Exception {
        UploadSession session;
        if (report.uploadSessionId == null || report.uploadSessionId.trim().isEmpty()) {
            session = createUploadSession(report, video);
        } else {
            session = new UploadSession();
            session.id = report.uploadSessionId;
            session.offset = probeUploadOffset(session.id, report.uploadOffset);
            session.chunkSize = DEFAULT_UPLOAD_CHUNK;
            if (session.offset < 0L) {
                report.uploadSessionId = "";
                report.uploadOffset = 0L;
                session = createUploadSession(report, video);
            }
        }
        if (session == null || session.id.isEmpty()) {
            throw new ResumableUnavailable("Server does not advertise resumable uploads");
        }
        long total = video.length();
        long offset = Math.max(0L, Math.min(total, session.offset));
        report.uploadSessionId = session.id;
        report.uploadOffset = offset;
        report.uploadTotal = total;
        postProgress(callback, offset, total);

        int chunkSize = Math.max(256 * 1024, Math.min(8 * 1024 * 1024,
                session.chunkSize <= 0 ? DEFAULT_UPLOAD_CHUNK : session.chunkSize));
        try (RandomAccessFile input = new RandomAccessFile(video, "r")) {
            input.seek(offset);
            byte[] buffer = new byte[64 * 1024];
            while (offset < total) {
                int requested = (int) Math.min(chunkSize, total - offset);
                HttpsURLConnection connection = null;
                try {
                    String endpoint = profiles.apiBase() + "/v1/uploads/" + encodePath(session.id);
                    connection = (HttpsURLConnection) checkedUrl(endpoint).openConnection();
                    activeConnection = connection;
                    configure(connection, "PUT");
                    connection.setDoOutput(true);
                    connection.setFixedLengthStreamingMode(requested);
                    connection.setRequestProperty("Content-Type", "application/offset+octet-stream");
                    connection.setRequestProperty("Upload-Offset", String.valueOf(offset));
                    connection.setRequestProperty("Upload-Length", String.valueOf(total));
                    try (BufferedOutputStream output = new BufferedOutputStream(
                            connection.getOutputStream(), 64 * 1024)) {
                        int remaining = requested;
                        while (remaining > 0) {
                            int read = input.read(buffer, 0, Math.min(buffer.length, remaining));
                            if (read < 0) throw new IOException("Video ended before upload completed");
                            output.write(buffer, 0, read);
                            remaining -= read;
                        }
                    }
                    Response ignored = response(connection);
                    long next = parseOffset(connection.getHeaderField("Upload-Offset"),
                            offset + requested);
                    if (next < offset + requested || next > total) {
                        throw new IOException("Server returned an invalid upload offset");
                    }
                    offset = next;
                    input.seek(offset);
                    report.uploadOffset = offset;
                    postProgress(callback, offset, total);
                } finally {
                    if (connection != null) connection.disconnect();
                    if (activeConnection == connection) activeConnection = null;
                }
            }
        }

        JSONObject complete = new JSONObject();
        complete.put("profile", profiles.profile().toJson());
        complete.put("report", report.toJson());
        Response response = request("POST", profiles.apiBase() + "/v1/uploads/"
                + encodePath(session.id) + "/complete", complete);
        return publishedReport(response.body, report);
    }

    private UploadSession createUploadSession(MonitorReport report, File video) throws Exception {
        JSONObject body = new JSONObject();
        body.put("profile", profiles.profile().toJson());
        body.put("report", report.toJson());
        body.put("file_size", video.length());
        body.put("content_type", "video/mp4");
        body.put("client", "DU World Monitor R30");
        try {
            Response response = request("POST", profiles.apiBase() + "/v1/uploads", body);
            JSONObject root = new JSONObject(response.body);
            JSONObject value = root.optJSONObject("upload");
            if (value == null) value = root;
            UploadSession session = new UploadSession();
            String candidateId = safe(value.optString("id",
                    value.optString("upload_id", "")), 160);
            session.id = candidateId.matches("[A-Za-z0-9._:-]+") ? candidateId : "";
            session.offset = Math.max(0L, value.optLong("offset", 0L));
            session.chunkSize = Math.max(0, value.optInt("chunk_size", DEFAULT_UPLOAD_CHUNK));
            if (session.id.isEmpty()) throw new ResumableUnavailable(
                    "Server did not return a resumable upload ID");
            return session;
        } catch (ResumableUnavailable unavailable) {
            throw unavailable;
        } catch (Exception error) {
            String detail = message(error).toUpperCase(Locale.ROOT);
            if (detail.contains("HTTP 404") || detail.contains("HTTP 405")
                    || detail.contains("HTTP 501")) {
                throw new ResumableUnavailable("Resumable endpoint unavailable");
            }
            throw error;
        }
    }

    private long probeUploadOffset(String uploadId, long fallback) throws Exception {
        HttpsURLConnection connection = null;
        try {
            String endpoint = profiles.apiBase() + "/v1/uploads/" + encodePath(uploadId);
            connection = (HttpsURLConnection) checkedUrl(endpoint).openConnection();
            activeConnection = connection;
            configure(connection, "HEAD");
            int code = connection.getResponseCode();
            if (code == 404 || code == 410) return -1L;
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
            return parseOffset(connection.getHeaderField("Upload-Offset"), fallback);
        } finally {
            if (connection != null) connection.disconnect();
            if (activeConnection == connection) activeConnection = null;
        }
    }

    private MonitorReport uploadMultipart(
            MonitorReport report,
            File video,
            UploadCallback callback) throws Exception {
        HttpsURLConnection connection = null;
        try {
            String boundary = "----DuMonitor" + UUID.randomUUID().toString().replace("-", "");
            URL url = checkedUrl(profiles.apiBase() + "/v1/reports");
            connection = (HttpsURLConnection) url.openConnection();
            activeConnection = connection;
            configure(connection, "POST");
            connection.setDoOutput(true);
            connection.setChunkedStreamingMode(64 * 1024);
            connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            long total = video.length();
            long sent = 0L;
            postProgress(callback, 0L, total);
            try (DataOutputStream output = new DataOutputStream(new BufferedOutputStream(
                    connection.getOutputStream(), 64 * 1024))) {
                writeTextPart(output, boundary, "report", report.toJson().toString(),
                        "application/json; charset=utf-8");
                output.writeBytes("--" + boundary + "\r\n");
                output.writeBytes("Content-Disposition: form-data; name=\"video\"; filename=\"report.mp4\"\r\n");
                output.writeBytes("Content-Type: video/mp4\r\n\r\n");
                try (BufferedInputStream input = new BufferedInputStream(
                        new FileInputStream(video), 64 * 1024)) {
                    byte[] buffer = new byte[64 * 1024];
                    int read;
                    long nextProgress = 512L * 1024L;
                    while ((read = input.read(buffer)) != -1) {
                        output.write(buffer, 0, read);
                        sent += read;
                        if (sent >= nextProgress || sent == total) {
                            postProgress(callback, sent, total);
                            nextProgress = sent + 512L * 1024L;
                        }
                    }
                }
                output.writeBytes("\r\n--" + boundary + "--\r\n");
                output.flush();
            }
            return publishedReport(response(connection).body, report);
        } finally {
            if (connection != null) connection.disconnect();
            if (activeConnection == connection) activeConnection = null;
        }
    }

    private MonitorReport publishedReport(String body, MonitorReport local) throws Exception {
        JSONObject root = new JSONObject(body);
        JSONObject reportJson = root.optJSONObject("report");
        if (reportJson == null) reportJson = root;
        MonitorReport published = MonitorReport.fromJson(reportJson);
        published.localFileName = local.localFileName;
        published.uploadState = MonitorReport.STATE_PUBLISHED;
        published.uploadError = "";
        published.uploadSessionId = "";
        published.uploadTotal = local.uploadTotal > 0L ? local.uploadTotal : published.uploadTotal;
        published.uploadOffset = published.uploadTotal;
        return published;
    }

    private void postProgress(UploadCallback callback, long sent, long total) {
        postToMain(() -> callback.onProgress(Math.max(0L, sent), Math.max(0L, total)));
    }

    private static long parseOffset(String value, long fallback) {
        try {
            return Math.max(0L, Long.parseLong(value == null ? "" : value.trim()));
        } catch (Exception ignored) {
            return Math.max(0L, fallback);
        }
    }

    public void postComment(
            String reportId,
            MonitorReport.Comment comment,
            ActionCallback callback) {
        JSONObject body = new JSONObject();
        try {
            body.put("profile", profiles.profile().toJson());
            body.put("comment", comment.toJson());
        } catch (Exception error) {
            callback.onResult(false, "Unable to prepare comment");
            return;
        }
        postAction("/v1/reports/" + encodePath(reportId) + "/comments", body, callback);
    }

    public void setLike(String reportId, boolean liked, ActionCallback callback) {
        JSONObject body = new JSONObject();
        try {
            body.put("profile_id", profiles.profile().id);
            body.put("liked", liked);
        } catch (Exception ignored) {
            // JSONObject created locally cannot fail for these primitive values.
        }
        postAction("/v1/reports/" + encodePath(reportId) + "/like", body, callback);
    }

    public void setFollowing(String profileId, boolean following, ActionCallback callback) {
        JSONObject body = new JSONObject();
        try {
            body.put("actor_profile_id", profiles.profile().id);
            body.put("following", following);
        } catch (Exception ignored) { }
        postAction("/v1/profiles/" + encodePath(profileId) + "/follow", body, callback);
    }

    public void reportContent(String reportId, String reason, ActionCallback callback) {
        JSONObject body = new JSONObject();
        try {
            body.put("profile_id", profiles.profile().id);
            body.put("reason", safe(reason, 240));
        } catch (Exception ignored) { }
        postAction("/v1/reports/" + encodePath(reportId) + "/flag", body, callback);
    }

    public void startLive(
            String title,
            String location,
            double latitude,
            double longitude,
            LiveCallback callback) {
        if (!profiles.networkConfigured()) {
            postToMain(() -> callback.onResult(null,
                    "Connect the Monitor Network before starting a live report"));
            return;
        }
        JSONObject body = new JSONObject();
        try {
            body.put("profile", profiles.profile().toJson());
            body.put("title", safe(title, 160));
            body.put("location_name", safe(location, 80));
            if (Double.isFinite(latitude) && Double.isFinite(longitude)) {
                body.put("latitude", latitude);
                body.put("longitude", longitude);
            }
            body.put("truth_state", "UNVERIFIED");
            body.put("client", "DU World Monitor R30");
        } catch (Exception error) {
            callback.onResult(null, "Unable to prepare the live session");
            return;
        }
        executor.execute(() -> {
            try {
                Response response = request("POST", profiles.apiBase() + "/v1/live/sessions", body);
                JSONObject root = new JSONObject(response.body);
                JSONObject value = root.optJSONObject("session");
                if (value == null) value = root;
                LiveSession session = LiveSession.fromJson(value);
                if (session == null) throw new IOException(
                        "The server did not return a safe publisher and playback session");
                postToMain(() -> callback.onResult(session, ""));
            } catch (Exception error) {
                postToMain(() -> callback.onResult(null, message(error)));
            }
        });
    }

    private void postAction(String path, JSONObject body, ActionCallback callback) {
        if (!profiles.networkConfigured()) {
            postToMain(() -> callback.onResult(false, "Saved on this phone; network not connected"));
            return;
        }
        executor.execute(() -> {
            try {
                request("POST", profiles.apiBase() + path, body);
                postToMain(() -> callback.onResult(true, "Synced"));
            } catch (Exception error) {
                postToMain(() -> callback.onResult(false, message(error)));
            }
        });
    }

    private Response request(String method, String endpoint, JSONObject body) throws Exception {
        HttpsURLConnection connection = null;
        try {
            connection = (HttpsURLConnection) checkedUrl(endpoint).openConnection();
            activeConnection = connection;
            configure(connection, method);
            if (body != null) {
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setDoOutput(true);
                connection.setFixedLengthStreamingMode(bytes.length);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                try (BufferedOutputStream output = new BufferedOutputStream(
                        connection.getOutputStream())) {
                    output.write(bytes);
                }
            }
            return response(connection);
        } finally {
            if (connection != null) connection.disconnect();
            if (activeConnection == connection) activeConnection = null;
        }
    }

    private void configure(HttpsURLConnection connection, String method) throws Exception {
        connection.setRequestMethod(method);
        connection.setInstanceFollowRedirects(false);
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("User-Agent", AppConfig.USER_AGENT + " LocalMonitors/30");
        String token = profiles.apiToken();
        if (!token.isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + token);
        String liveToken = profiles.liveToken();
        if (!liveToken.isEmpty()) connection.setRequestProperty("X-DU-Live-Token", liveToken);
    }

    private Response response(HttpsURLConnection connection) throws Exception {
        int code = connection.getResponseCode();
        if (code >= 300 && code < 400) {
            throw new IOException("Redirects are refused for authenticated Monitor Network requests");
        }
        InputStream stream = code >= 200 && code < 300
                ? connection.getInputStream() : connection.getErrorStream();
        String body = readBounded(stream);
        if (code < 200 || code >= 300) {
            String detail = "HTTP " + code;
            try {
                String server = new JSONObject(body).optString("message", "");
                if (!server.trim().isEmpty()) detail += " / " + safe(server, 180);
            } catch (Exception ignored) { }
            throw new IOException(detail);
        }
        return new Response(code, body);
    }

    private static String readBounded(InputStream raw) throws IOException {
        if (raw == null) return "{}";
        try (InputStream input = new BufferedInputStream(raw);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16 * 1024];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_JSON_BYTES) throw new IOException("Monitor response too large");
                output.write(buffer, 0, read);
            }
            return output.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static void writeTextPart(
            DataOutputStream output,
            String boundary,
            String name,
            String value,
            String contentType) throws IOException {
        output.writeBytes("--" + boundary + "\r\n");
        output.writeBytes("Content-Disposition: form-data; name=\"" + name + "\"\r\n");
        output.writeBytes("Content-Type: " + contentType + "\r\n\r\n");
        output.write(value.getBytes(StandardCharsets.UTF_8));
        output.writeBytes("\r\n");
    }

    private static URL checkedUrl(String value) throws Exception {
        if (!MonitorReport.safeHttps(value)) throw new IOException("Unsafe network address refused");
        URL url = new URL(value);
        if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getUserInfo() != null
                || url.getHost() == null || url.getHost().trim().isEmpty()) {
            throw new IOException("Only public HTTPS Monitor Network addresses are allowed");
        }
        return url;
    }

    private static String encode(String value) {
        try {
            return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8.name());
        } catch (Exception ignored) {
            return "";
        }
    }

    private static String encodePath(String value) {
        return encode(safe(value, 120)).replace("+", "%20");
    }

    private static String normalFilter(String value) {
        String clean = safe(value, 24).toUpperCase(Locale.ROOT);
        if ("LIVE".equals(clean) || "NEARBY".equals(clean) || "FOLLOWING".equals(clean)) {
            return clean;
        }
        return "FOR_YOU";
    }

    private static String safe(String value, int maximum) {
        return MonitorReport.trim(value, maximum).replaceAll("[\\r\\n\\t]+", " ");
    }

    private static String message(Exception error) {
        String value = error == null ? "Network request failed" : error.getMessage();
        if (value == null || value.trim().isEmpty()) value = "Network request failed";
        return safe(value, 220);
    }

    public void shutdown() {
        shutdown = true;
        HttpsURLConnection connection = activeConnection;
        if (connection != null) connection.disconnect();
        executor.shutdownNow();
        main.removeCallbacksAndMessages(null);
    }

    private void postToMain(Runnable action) {
        if (action == null || shutdown) return;
        main.post(() -> {
            if (shutdown) return;
            try {
                action.run();
            } catch (RuntimeException error) {
                // A late UI callback is isolated from the process; the activity owns its state.
            }
        });
    }

    private static final class Response {
        final int code;
        final String body;

        Response(int code, String body) {
            this.code = code;
            this.body = body == null || body.trim().isEmpty() ? "{}" : body;
        }
    }

    public interface FeedCallback {
        void onResult(List<MonitorReport> reports, String error);
    }

    public interface CommentsCallback {
        void onResult(List<MonitorReport.Comment> comments, String error);
    }

    public interface UploadCallback {
        default void onProgress(long uploadedBytes, long totalBytes) { }
        void onResult(MonitorReport report, String error);
    }

    public interface ActionCallback {
        void onResult(boolean success, String message);
    }

    public interface LiveCallback {
        void onResult(LiveSession session, String error);
    }

    public static final class LiveSession {
        public String id = "";
        public String publisherUrl = "";
        public String playbackUrl = "";
        public String reportId = "";
        public long expiresAtMs;

        static LiveSession fromJson(JSONObject value) {
            LiveSession session = new LiveSession();
            session.id = safe(value.optString("id", value.optString("session_id", "")), 120);
            session.publisherUrl = value.optString("publisher_url", "").trim();
            session.playbackUrl = value.optString("playback_url", "").trim();
            session.reportId = safe(value.optString("report_id", ""), 120);
            session.expiresAtMs = Math.max(0L, value.optLong("expires_at_ms", 0L));
            if (session.id.isEmpty() || !MonitorReport.safeHttps(session.publisherUrl)
                    || !MonitorReport.safeHttps(session.playbackUrl)) return null;
            return session;
        }
    }

    private static final class UploadSession {
        String id = "";
        long offset;
        int chunkSize;
    }

    private static final class ResumableUnavailable extends IOException {
        ResumableUnavailable(String message) {
            super(message);
        }
    }
}
