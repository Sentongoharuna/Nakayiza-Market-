package com.sentongoharuna.worldsituationroom;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** A source-labelled local-monitor video report. No state is inferred as verified. */
public final class MonitorReport {
    public static final String STATE_LOCAL = "LOCAL_ONLY";
    public static final String STATE_DRAFT = "DRAFT";
    public static final String STATE_QUEUED = "QUEUED";
    public static final String STATE_UPLOADING = "UPLOADING";
    public static final String STATE_PUBLISHED = "PUBLISHED";
    public static final String STATE_FAILED = "FAILED";

    public String id = UUID.randomUUID().toString();
    public String profileId = "";
    public String displayName = "Local Monitor";
    public String handle = "@localmonitor";
    public String avatarUrl = "";
    public String locationName = "Location not stated";
    public String headline = "";
    public String caption = "";
    public String category = "LOCAL UPDATE";
    public String truthState = "UNVERIFIED";
    public String sourceLabel = "LOCAL MONITOR";
    public String videoUrl = "";
    public String shareUrl = "";
    public String localFileName = "";
    public String uploadState = STATE_LOCAL;
    public String uploadError = "";
    public String uploadSessionId = "";
    public long createdAtMs = System.currentTimeMillis();
    public long expiresAtMs;
    public long durationMs;
    public long uploadOffset;
    public long uploadTotal;
    public int likes;
    public int commentCount;
    public int viewerCount;
    public int avatarColor = 0xff70b1c9;
    public double latitude = Double.NaN;
    public double longitude = Double.NaN;
    public boolean live;
    public boolean story;
    public boolean liked;
    public boolean following;
    public boolean profileVerified;
    public boolean locationApproximate;

    public boolean hasLocalVideo() {
        return !clean(localFileName).isEmpty();
    }

    public boolean hasRemoteVideo() {
        return safeHttps(videoUrl);
    }

    public boolean isDraft() {
        return STATE_DRAFT.equals(uploadState);
    }

    public boolean isExpired(long nowMs) {
        return story && expiresAtMs > 0L && expiresAtMs <= nowMs;
    }

    public String stateLine() {
        if (live) return "LIVE / " + safeTruth(truthState);
        if (STATE_DRAFT.equals(uploadState)) return "PRIVATE DRAFT / THIS PHONE";
        if (STATE_UPLOADING.equals(uploadState)) {
            int percent = uploadTotal > 0L
                    ? (int) Math.min(99L, uploadOffset * 100L / uploadTotal) : 0;
            return "UPLOADING / " + percent + "% / LOCAL COPY SAFE";
        }
        if (STATE_QUEUED.equals(uploadState)) return "QUEUED FOR SECURE UPLOAD";
        if (STATE_FAILED.equals(uploadState)) return "UPLOAD FAILED / TAP RETRY";
        if (STATE_LOCAL.equals(uploadState)) return "ON THIS PHONE / NOT SYNCED";
        return safeTruth(truthState) + " / NETWORK REPORT";
    }

    public String ageText(long nowMs) {
        long age = Math.max(0L, nowMs - createdAtMs);
        if (age < 60_000L) return Math.max(1L, age / 1_000L) + "s";
        if (age < 3_600_000L) return age / 60_000L + "m";
        if (age < 86_400_000L) return age / 3_600_000L + "h";
        return age / 86_400_000L + "d";
    }

    public JSONObject toJson() throws JSONException {
        JSONObject value = new JSONObject();
        value.put("id", clean(id));
        value.put("profile_id", clean(profileId));
        value.put("display_name", clean(displayName));
        value.put("handle", clean(handle));
        value.put("avatar_url", clean(avatarUrl));
        value.put("location_name", clean(locationName));
        value.put("headline", clean(headline));
        value.put("caption", clean(caption));
        value.put("category", clean(category));
        value.put("truth_state", safeTruth(truthState));
        value.put("source_label", clean(sourceLabel));
        value.put("video_url", clean(videoUrl));
        value.put("share_url", clean(shareUrl));
        value.put("local_file_name", clean(localFileName));
        value.put("upload_state", clean(uploadState));
        value.put("upload_error", clean(uploadError));
        value.put("upload_session_id", clean(uploadSessionId));
        value.put("created_at_ms", createdAtMs);
        value.put("expires_at_ms", expiresAtMs);
        value.put("duration_ms", durationMs);
        value.put("upload_offset", uploadOffset);
        value.put("upload_total", uploadTotal);
        value.put("likes", likes);
        value.put("comment_count", commentCount);
        value.put("viewer_count", viewerCount);
        value.put("avatar_color", avatarColor);
        if (Double.isFinite(latitude) && Double.isFinite(longitude)) {
            value.put("latitude", latitude);
            value.put("longitude", longitude);
        }
        value.put("live", live);
        value.put("story", story);
        value.put("liked", liked);
        value.put("following", following);
        value.put("profile_verified", profileVerified);
        value.put("location_approximate", locationApproximate);
        return value;
    }

    public static MonitorReport fromJson(JSONObject value) {
        MonitorReport report = new MonitorReport();
        report.id = first(value, "id", "report_id", report.id);
        report.profileId = first(value, "profile_id", "author_id", "");
        report.displayName = first(value, "display_name", "author_name", "Local Monitor");
        report.handle = normalHandle(first(value, "handle", "author_handle", "localmonitor"));
        report.avatarUrl = safeHttps(value.optString("avatar_url", ""))
                ? value.optString("avatar_url", "").trim() : "";
        report.locationName = first(value, "location_name", "location", "Location not stated");
        report.headline = first(value, "headline", "title", "");
        report.caption = first(value, "caption", "description", "");
        report.category = first(value, "category", "type", "LOCAL UPDATE");
        report.truthState = safeTruth(first(value, "truth_state", "credibility", "UNVERIFIED"));
        report.sourceLabel = first(value, "source_label", "source", "LOCAL MONITOR");
        report.videoUrl = safeHttps(value.optString("video_url", ""))
                ? value.optString("video_url", "").trim() : "";
        report.shareUrl = safeHttps(value.optString("share_url", ""))
                ? value.optString("share_url", "").trim() : "";
        report.localFileName = safeFileName(value.optString("local_file_name", ""));
        report.uploadState = safeUploadState(value.optString("upload_state", STATE_PUBLISHED));
        report.uploadError = trim(value.optString("upload_error", ""), 240);
        report.uploadSessionId = safeId(value.optString("upload_session_id", ""));
        report.createdAtMs = positiveLong(value, "created_at_ms", System.currentTimeMillis());
        report.expiresAtMs = positiveLong(value, "expires_at_ms", 0L);
        report.durationMs = positiveLong(value, "duration_ms", 0L);
        report.uploadOffset = positiveLong(value, "upload_offset", 0L);
        report.uploadTotal = positiveLong(value, "upload_total", 0L);
        report.likes = bounded(value.optInt("likes", 0), 0, 1_000_000_000);
        report.commentCount = bounded(value.optInt("comment_count", 0), 0, 1_000_000_000);
        report.viewerCount = bounded(value.optInt("viewer_count", 0), 0, 1_000_000_000);
        report.avatarColor = value.optInt("avatar_color", 0xff70b1c9);
        report.latitude = finiteCoordinate(value.optDouble("latitude", Double.NaN), -90d, 90d);
        report.longitude = finiteCoordinate(value.optDouble("longitude", Double.NaN), -180d, 180d);
        report.live = value.optBoolean("live", false);
        report.story = value.optBoolean("story", false);
        report.liked = value.optBoolean("liked", false);
        report.following = value.optBoolean("following", false);
        report.profileVerified = value.optBoolean("profile_verified", false);
        report.locationApproximate = value.optBoolean("location_approximate", false);
        return report;
    }

    public static List<MonitorReport> listFromJson(String json) {
        List<MonitorReport> reports = new ArrayList<>();
        if (json == null || json.trim().isEmpty()) return reports;
        try {
            Object root = new org.json.JSONTokener(json).nextValue();
            JSONArray values;
            if (root instanceof JSONArray) {
                values = (JSONArray) root;
            } else if (root instanceof JSONObject) {
                JSONObject object = (JSONObject) root;
                values = object.optJSONArray("reports");
                if (values == null) values = object.optJSONArray("items");
            } else {
                return reports;
            }
            if (values == null) return reports;
            int limit = Math.min(values.length(), 100);
            for (int index = 0; index < limit; index++) {
                JSONObject value = values.optJSONObject(index);
                if (value == null) continue;
                MonitorReport report = fromJson(value);
                if ((report.hasRemoteVideo() || report.hasLocalVideo())
                        && !report.isExpired(System.currentTimeMillis())) {
                    reports.add(report);
                }
            }
        } catch (Exception ignored) {
            // A malformed network response must never replace the existing local feed.
        }
        return reports;
    }

    public static String normalHandle(String value) {
        String clean = trim(value, 32).replaceAll("[^A-Za-z0-9_.]", "");
        if (clean.isEmpty()) clean = "localmonitor";
        return "@" + clean.toLowerCase(Locale.ROOT);
    }

    public static String safeTruth(String value) {
        String clean = trim(value, 24).toUpperCase(Locale.ROOT);
        if ("CONFIRMED".equals(clean) || "REPORTED".equals(clean)) return clean;
        return "UNVERIFIED";
    }

    public static boolean safeHttps(String value) {
        if (value == null) return false;
        String clean = value.trim().toLowerCase(Locale.ROOT);
        return clean.startsWith("https://") && clean.length() <= 2_048;
    }

    public static String clean(String value) {
        return trim(value, 2_048);
    }

    public static String trim(String value, int maximum) {
        String clean = value == null ? "" : value.trim();
        return clean.length() <= maximum ? clean : clean.substring(0, maximum);
    }

    private static String first(JSONObject value, String first, String second, String fallback) {
        String candidate = value.optString(first, "").trim();
        if (candidate.isEmpty()) candidate = value.optString(second, "").trim();
        return candidate.isEmpty() ? fallback : trim(candidate, 2_048);
    }

    private static long positiveLong(JSONObject value, String name, long fallback) {
        long candidate = value.optLong(name, fallback);
        return candidate < 0L ? fallback : candidate;
    }

    private static int bounded(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static double finiteCoordinate(double value, double minimum, double maximum) {
        return Double.isFinite(value) && value >= minimum && value <= maximum
                ? value : Double.NaN;
    }

    private static String safeFileName(String value) {
        String clean = trim(value, 100);
        return clean.matches("[A-Za-z0-9._-]+") ? clean : "";
    }

    private static String safeUploadState(String value) {
        String clean = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (STATE_DRAFT.equals(clean) || STATE_QUEUED.equals(clean)
                || STATE_UPLOADING.equals(clean) || STATE_PUBLISHED.equals(clean)
                || STATE_FAILED.equals(clean)) return clean;
        return STATE_LOCAL;
    }

    private static String safeId(String value) {
        String clean = trim(value, 160);
        return clean.matches("[A-Za-z0-9._:-]+") ? clean : "";
    }

    public static final class Comment {
        public String id = UUID.randomUUID().toString();
        public String profileId = "";
        public String displayName = "Local Monitor";
        public String handle = "@localmonitor";
        public String body = "";
        public long createdAtMs = System.currentTimeMillis();
        public boolean pending;

        public JSONObject toJson() throws JSONException {
            JSONObject value = new JSONObject();
            value.put("id", id);
            value.put("profile_id", profileId);
            value.put("display_name", displayName);
            value.put("handle", handle);
            value.put("body", body);
            value.put("created_at_ms", createdAtMs);
            value.put("pending", pending);
            return value;
        }

        public static Comment fromJson(JSONObject value) {
            Comment comment = new Comment();
            comment.id = first(value, "id", "comment_id", comment.id);
            comment.profileId = first(value, "profile_id", "author_id", "");
            comment.displayName = first(value, "display_name", "author_name", "Local Monitor");
            comment.handle = normalHandle(first(value, "handle", "author_handle", "localmonitor"));
            comment.body = trim(value.optString("body", ""), 500);
            comment.createdAtMs = positiveLong(value, "created_at_ms", System.currentTimeMillis());
            comment.pending = value.optBoolean("pending", false);
            return comment;
        }
    }
}
