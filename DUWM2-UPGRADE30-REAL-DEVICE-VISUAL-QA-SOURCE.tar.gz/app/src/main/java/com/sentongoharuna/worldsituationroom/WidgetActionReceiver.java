package com.sentongoharuna.worldsituationroom;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Handles refresh and record navigation without opening the full application. */
public final class WidgetActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        int widgetId = intent.getIntExtra(DuWidgetContract.EXTRA_WIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return;
        DuWidgetContract.Kind kind = parseKind(intent.getStringExtra(
                DuWidgetContract.EXTRA_WIDGET_KIND));
        String action = intent.getAction();
        if (DuWidgetContract.ACTION_NEXT.equals(action)) {
            new DuWidgetPreferences(context).moveCursor(widgetId, kind, 1);
            DuWidgetUpdater.updateSingle(context, widgetId, kind);
        } else if (DuWidgetContract.ACTION_PREVIOUS.equals(action)) {
            new DuWidgetPreferences(context).moveCursor(widgetId, kind, -1);
            DuWidgetUpdater.updateSingle(context, widgetId, kind);
        } else if (DuWidgetContract.ACTION_REFRESH.equals(action)) {
            DuWidgetUpdater.updateSingle(context, widgetId, kind);
            WidgetRefreshScheduler.scheduleImmediate(context);
        }
    }

    private static DuWidgetContract.Kind parseKind(String value) {
        try { return DuWidgetContract.Kind.valueOf(value == null ? "" : value); }
        catch (IllegalArgumentException ignored) { return DuWidgetContract.Kind.COMMAND; }
    }
}
