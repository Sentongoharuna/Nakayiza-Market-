package com.sentongoharuna.worldsituationroom;
import java.util.*;import java.util.regex.*;
public final class DuCommandQuery{
 public String raw="",system="GLOBE",place="",id="",text="";public double radiusKm=Double.NaN;public long windowMs=0;
 public static DuCommandQuery parse(String raw){DuCommandQuery q=new DuCommandQuery();q.raw=raw==null?"":raw.trim();String s=q.raw.toLowerCase(Locale.ROOT);
  q.system=s.matches(".*\\b(aircraft|flight|flights|plane|planes)\\b.*")?"AIR":s.matches(".*\\b(ship|ships|vessel|vessels)\\b.*")?"SEA":s.matches(".*\\b(satellite|satellites|orbit|orbital)\\b.*")?"ORBIT":s.matches(".*\\b(weather|rain|storm|radar|wx)\\b.*")?"WX":s.matches(".*\\b(earthquake|earthquakes|event|events|wildfire|volcano)\\b.*")?"EVENTS":s.matches(".*\\b(news|story|stories|wire)\\b.*")?"NEWS":"GLOBE";
  Matcher r=Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(km|kilomet(?:er|re)s?)").matcher(s);if(r.find())q.radiusKm=Double.parseDouble(r.group(1));
  Matcher h=Pattern.compile("(?:last|past)\\s+(\\d+)\\s*(hour|hours|hr|hrs|day|days)").matcher(s);if(h.find()){long n=Long.parseLong(h.group(1));q.windowMs=n*(h.group(2).startsWith("day")?86400000L:3600000L);}
  Matcher near=Pattern.compile("(?:near|around|in|within\\s+\\d+(?:\\.\\d+)?\\s*(?:km|kilomet(?:er|re)s?)\\s+(?:of\\s+)?)\\s*([a-z][a-z .'-]{2,40})").matcher(s);if(near.find())q.place=cleanPlace(near.group(1));
  Matcher id=Pattern.compile("(?:id|track|satellite)\\s+([a-z0-9:_-]{3,40})",Pattern.CASE_INSENSITIVE).matcher(q.raw);if(id.find())q.id=id.group(1);
  q.text=s.replaceAll("\\b(show|find|open|track|me|the|all|near|around|within|last|past|hours?|days?|aircraft|flights?|planes?|ships?|vessels?|satellites?|orbit|orbital|weather|rain|storm|radar|earthquakes?|events?|wildfire|volcano|news|stories?|wire|km|kilometers?|kilometres?)\\b"," ").replaceAll("\\d+"," ").replaceAll("\\s+"," ").trim();return q;}
 static String cleanPlace(String s){return s.replaceAll("\\b(today|now|last|past|with|that|from)\\b.*$","").trim();}
}