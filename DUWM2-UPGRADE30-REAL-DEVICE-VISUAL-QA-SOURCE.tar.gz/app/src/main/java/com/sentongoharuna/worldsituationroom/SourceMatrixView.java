package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

import java.util.EnumMap;
import java.util.Locale;

/** Compact per-source health lights. Pulses are finite and independently event-driven. */
public final class SourceMatrixView extends View {
    private static final Signal.Layer[] LANES = {
            Signal.Layer.FLIGHTS, Signal.Layer.SHIPS, Signal.Layer.WEATHER,
            Signal.Layer.AIRSPACE, Signal.Layer.NATURAL, Signal.Layer.NEWS,
            Signal.Layer.SATELLITES, Signal.Layer.WEBCAMS,
            Signal.Layer.RADIO, Signal.Layer.TV
    };
    private static final String[] LABELS = {
            "AIR", "SEA", "WX", "AWX", "EVT", "WIRE", "SAT", "CAM", "RAD", "TV"
    };
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final EnumMap<Signal.Layer, LaneState> states =
            new EnumMap<>(Signal.Layer.class);

    public SourceMatrixView(Context context) {
        super(context);
        textPaint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        setBackgroundColor(Color.TRANSPARENT);
        setContentDescription("Per-source live operations matrix");
    }

    public void update(Signal.Layer layer, LiveOperationsEngine.LayerSnapshot snapshot) {
        if (snapshot == null || laneIndex(layer) < 0) return;
        LaneState previous = states.get(layer);
        boolean changed = previous == null
                || previous.condition != snapshot.condition
                || previous.count != snapshot.providerCount;
        long started = changed ? SystemClock.uptimeMillis()
                + laneIndex(layer) * 47L : previous.pulseStartedMs;
        states.put(layer, new LaneState(snapshot.condition, snapshot.providerCount,
                snapshot.sourceAgeMs, started));
        updateDescription();
        if (changed) postInvalidateOnAnimation();
        else invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density = getResources().getDisplayMetrics().density;
        float scaled = getResources().getDisplayMetrics().scaledDensity;
        float cell = getWidth() / (float) LANES.length;
        long now = SystemClock.uptimeMillis();
        boolean active = false;
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setTextSize(5.8f * scaled);
        for (int index = 0; index < LANES.length; index++) {
            LaneState state = states.get(LANES[index]);
            LiveOperationsEngine.SourceCondition condition = state == null
                    ? LiveOperationsEngine.SourceCondition.ACQUIRING : state.condition;
            int color = colorFor(condition);
            float cx = cell * index + cell * 0.5f;
            float cy = Math.min(getHeight() * 0.34f, 6.5f * density);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(color);
            canvas.drawCircle(cx, cy, Math.max(2.2f * density, 2.8f), paint);
            if (state != null) {
                long elapsed = now - state.pulseStartedMs;
                long duration = pulseDuration(condition);
                if (elapsed >= 0L && elapsed < duration) {
                    active = true;
                    float progress = elapsed / (float) duration;
                    float rhythm = (float) Math.abs(Math.sin(progress * Math.PI
                            * pulseBeats(condition)));
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth((0.7f + rhythm) * density);
                    paint.setColor(Color.argb((int) ((1f - progress) * 190f),
                            Color.red(color), Color.green(color), Color.blue(color)));
                    canvas.drawCircle(cx, cy, (4f + progress * 7f + rhythm * 2f) * density,
                            paint);
                }
            }
            textPaint.setColor(Color.argb(220, 191, 207, 215));
            canvas.drawText(LABELS[index], cx, getHeight() - 1.5f * density, textPaint);
        }
        if (active) postInvalidateOnAnimation();
    }

    private void updateDescription() {
        StringBuilder description = new StringBuilder("Source matrix. ");
        for (int index = 0; index < LANES.length; index++) {
            LaneState state = states.get(LANES[index]);
            if (index > 0) description.append("; ");
            description.append(LABELS[index]).append(' ');
            if (state == null) {
                description.append("acquiring");
            } else {
                description.append(state.condition.name().toLowerCase(Locale.ROOT))
                        .append(", ").append(state.count).append(" records, age ")
                        .append(LiveOperationsEngine.ageLabel(state.ageMs));
            }
        }
        setContentDescription(description.toString());
    }

    private static int laneIndex(Signal.Layer layer) {
        for (int index = 0; index < LANES.length; index++) {
            if (LANES[index] == layer) return index;
        }
        return -1;
    }

    private static int colorFor(LiveOperationsEngine.SourceCondition condition) {
        switch (condition) {
            case FRESH: return Color.rgb(75, 196, 126);
            case ACQUIRING: return Color.rgb(84, 183, 221);
            case OFFLINE: return Color.rgb(229, 73, 80);
            case DELAYED:
            case CACHED:
            case KEY_REQUIRED:
            default: return Color.rgb(221, 164, 65);
        }
    }

    private static long pulseDuration(LiveOperationsEngine.SourceCondition condition) {
        switch (condition) {
            case OFFLINE: return 2_700L;
            case DELAYED:
            case CACHED:
            case KEY_REQUIRED: return 2_100L;
            default: return 1_450L;
        }
    }

    private static int pulseBeats(LiveOperationsEngine.SourceCondition condition) {
        switch (condition) {
            case OFFLINE: return 4;
            case DELAYED:
            case CACHED:
            case KEY_REQUIRED: return 3;
            default: return 2;
        }
    }

    private static final class LaneState {
        final LiveOperationsEngine.SourceCondition condition;
        final int count;
        final long ageMs;
        final long pulseStartedMs;

        LaneState(LiveOperationsEngine.SourceCondition condition, int count,
                  long ageMs, long pulseStartedMs) {
            this.condition = condition;
            this.count = count;
            this.ageMs = ageMs;
            this.pulseStartedMs = pulseStartedMs;
        }
    }
}
