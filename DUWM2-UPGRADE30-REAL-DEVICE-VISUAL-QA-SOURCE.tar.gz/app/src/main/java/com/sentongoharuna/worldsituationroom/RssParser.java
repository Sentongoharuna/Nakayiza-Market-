package com.sentongoharuna.worldsituationroom;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.StringReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Minimal RSS/Atom parser; it never executes feed content. */
public final class RssParser {
    public static final class Item {
        public String title = "";
        public String link = "";
        public String description = "";
        public long timestampMs = System.currentTimeMillis();
    }

    private RssParser() {}

    public static List<Item> parse(String xml) throws Exception {
        List<Item> result = new ArrayList<>();
        XmlPullParser parser = Xml.newPullParser();
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
        parser.setInput(new StringReader(xml));
        Item current = null;
        int event = parser.getEventType();
        while (event != XmlPullParser.END_DOCUMENT && result.size() < 80) {
            if (event == XmlPullParser.START_TAG) {
                String name = parser.getName().toLowerCase(Locale.ROOT);
                if (name.equals("item") || name.equals("entry")) {
                    current = new Item();
                } else if (current != null) {
                    if (name.equals("title")) {
                        current.title = safeText(parser);
                    } else if (name.equals("link")) {
                        String href = parser.getAttributeValue(null, "href");
                        current.link = href == null ? safeText(parser) : href;
                    } else if (name.equals("description") || name.equals("summary")) {
                        current.description = stripMarkup(safeText(parser));
                    } else if (name.equals("pubdate") || name.equals("published")
                            || name.equals("updated")) {
                        current.timestampMs = parseDate(safeText(parser));
                    }
                }
            } else if (event == XmlPullParser.END_TAG && current != null) {
                String name = parser.getName().toLowerCase(Locale.ROOT);
                if (name.equals("item") || name.equals("entry")) {
                    if (!current.title.trim().isEmpty()) {
                        result.add(current);
                    }
                    current = null;
                }
            }
            event = parser.next();
        }
        return result;
    }

    private static String safeText(XmlPullParser parser) throws Exception {
        return parser.nextText().trim();
    }

    private static String stripMarkup(String value) {
        return value.replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").trim();
    }

    private static long parseDate(String value) {
        String[] patterns = {
                "EEE, dd MMM yyyy HH:mm:ss Z",
                "EEE, dd MMM yyyy HH:mm Z",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd'T'HH:mm:ss'Z'"
        };
        for (String pattern : patterns) {
            try {
                SimpleDateFormat format = new SimpleDateFormat(pattern, Locale.US);
                format.setLenient(true);
                Date parsed = format.parse(value);
                if (parsed != null) {
                    return parsed.getTime();
                }
            } catch (ParseException ignored) {
                // Try the next widely used RSS date pattern.
            }
        }
        return System.currentTimeMillis();
    }
}
