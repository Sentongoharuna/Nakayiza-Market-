package com.sentongoharuna.worldsituationroom;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

/** Shared lifecycle for all eight independently resizable home-screen widgets. */
public abstract class BaseSituationWidgetProvider extends AppWidgetProvider {
    protected abstract DuWidgetContract.Kind kind();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] widgetIds) {
        for (int widgetId : widgetIds) {
            DuWidgetUpdater.updateSingle(context, widgetId, kind());
        }
        WidgetRefreshScheduler.schedulePeriodic(context);
        WidgetRefreshScheduler.scheduleImmediate(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int widgetId, Bundle options) {
        DuWidgetUpdater.updateSingle(context, widgetId, kind());
    }

    @Override
    public void onDeleted(Context context, int[] widgetIds) {
        DuWidgetPreferences profiles = new DuWidgetPreferences(context);
        for (int widgetId : widgetIds) profiles.delete(widgetId);
        if (!DuWidgetUpdater.hasWidgets(context)) WidgetRefreshScheduler.cancel(context);
    }

    @Override
    public void onEnabled(Context context) {
        WidgetRefreshScheduler.schedulePeriodic(context);
        WidgetRefreshScheduler.scheduleImmediate(context);
        DuWidgetUpdater.requestUpdate(context);
    }

    @Override
    public void onDisabled(Context context) {
        if (!DuWidgetUpdater.hasWidgets(context)) WidgetRefreshScheduler.cancel(context);
    }
}
