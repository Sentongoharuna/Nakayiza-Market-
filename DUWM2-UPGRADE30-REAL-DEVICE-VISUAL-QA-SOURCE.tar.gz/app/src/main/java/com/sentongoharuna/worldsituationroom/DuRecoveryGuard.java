package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.content.*;import java.util.*;
public final class DuRecoveryGuard{
 public static List<Signal> valid(Context c,String area,List<Signal> in){List<Signal> out=new ArrayList<>();if(in==null){DuRecoveryState.fail(c,area,"Provider returned null collection");return out;}int bad=0;for(Signal s:in){if(s==null||s.id==null||s.id.trim().isEmpty()||s.title==null){bad++;continue;}out.add(s);}if(bad>0)DuRecoveryState.fail(c,area,bad+" malformed record(s) ignored");else DuRecoveryState.ok(c,area);return out;}
 public static void safeOpen(Activity a,Intent i,String area){try{a.startActivity(i);DuRecoveryState.ok(a,area);}catch(RuntimeException e){DuRecoveryState.fail(a,area,e.getMessage());}}
}