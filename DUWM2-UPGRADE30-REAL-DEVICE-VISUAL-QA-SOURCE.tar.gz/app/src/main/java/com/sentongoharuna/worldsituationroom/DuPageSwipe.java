package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.view.*;
public final class DuPageSwipe implements View.OnTouchListener{
 final Activity a;final String prev,next;final DuGestureCoordinator g;float x;
 public DuPageSwipe(Activity a,String p,String n){this.a=a;prev=p;next=n;g=new DuGestureCoordinator(a);}
 public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:x=e.getX();g.down(e,v.getWidth());return false;case MotionEvent.ACTION_MOVE:return g.move(e,false,false)==DuGestureCoordinator.Owner.PAGE;case MotionEvent.ACTION_UP:float dx=e.getX()-x;DuGestureCoordinator.Owner o=g.move(e,false,false);g.release();if(o==DuGestureCoordinator.Owner.PAGE&&Math.abs(dx)>Du2Ui.dp(a,72)){String q=dx>0?prev:next;if(q!=null&&!q.isEmpty()){DuPageRouter.open(a,q);return true;}}return false;case MotionEvent.ACTION_CANCEL:g.release();}return false;}
}