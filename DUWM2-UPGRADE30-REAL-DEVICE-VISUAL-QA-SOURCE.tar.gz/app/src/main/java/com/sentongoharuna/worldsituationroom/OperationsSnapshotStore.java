package com.sentongoharuna.worldsituationroom;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Durable last-known operations snapshots. Raw HTTP caches remain provider-specific; this
 * compact normalized store lets the command deck restore aircraft, vessels and other layers
 * immediately after process death. Restored records are always labelled CACHED.
 */
public final class OperationsSnapshotStore {
    public static final class Snapshot {
        public final Signal.Layer layer;
        public final List<Signal> signals;
        public final FeedStatus status;
        public final long savedAtMs;

        Snapshot(Signal.Layer layer, List<Signal> signals,
                 FeedStatus status, long savedAtMs) {
            this.layer = layer;
            this.signals = signals;
            this.status = status;
            this.savedAtMs = savedAtMs;
        }
    }

    private static final int FORMAT_VERSION = 1;
    private static final int MAX_FILE_BYTES = 24 * 1024 * 1024;
    private final File directory;
    private final ExecutorService writer = Executors.newSingleThreadExecutor();
    private final EnumMap<Signal.Layer, Long> lastQueuedAt =
            new EnumMap<>(Signal.Layer.class);

    public OperationsSnapshotStore(Context context) {
        directory = new File(context.getApplicationContext().getFilesDir(),
                "operations-snapshots-v1");
        if (!directory.exists()) directory.mkdirs();
    }

    public synchronized void saveAsync(
            Signal.Layer layer,
            List<Signal> signals,
            FeedStatus status) {
        if (status == null || signals == null || signals.isEmpty()) return;
        if (status.state != FeedStatus.State.LIVE
                && status.state != FeedStatus.State.READY) return;
        long now = System.currentTimeMillis();
        Long last = lastQueuedAt.get(layer);
        if (last != null && now - last < snapshotWriteIntervalMs(layer)) return;
        lastQueuedAt.put(layer, now);
        int cap = snapshotCap(layer);
        List<Signal> copy = new ArrayList<>(signals.subList(0, Math.min(cap, signals.size())));
        FeedStatus statusCopy = new FeedStatus(status.state, status.count,
                status.message, status.updatedAtMs);
        try {
            writer.execute(() -> write(layer, copy, statusCopy));
        } catch (RuntimeException ignored) {
            // Shutdown can race a final provider callback; the previous snapshot stays valid.
        }
    }

    public EnumMap<Signal.Layer, Snapshot> loadAll() {
        EnumMap<Signal.Layer, Snapshot> result = new EnumMap<>(Signal.Layer.class);
        for (Signal.Layer layer : Signal.Layer.values()) {
            Snapshot snapshot = read(layer);
            if (snapshot != null) result.put(layer, snapshot);
        }
        return result;
    }

    public void shutdown() {
        writer.shutdownNow();
    }

    private void write(Signal.Layer layer, List<Signal> signals, FeedStatus status) {
        try {
            long savedAt = System.currentTimeMillis();
            JSONObject root = new JSONObject();
            root.put("format", FORMAT_VERSION);
            root.put("layer", layer.name());
            root.put("savedAt", savedAt);
            root.put("providerCount", status.count);
            root.put("providerMessage", status.message);
            JSONArray values = new JSONArray();
            for (Signal signal : signals) values.put(toJson(signal));
            root.put("signals", values);
            byte[] bytes = root.toString().getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_FILE_BYTES) return;
            File target = fileFor(layer);
            File temporary = new File(directory, target.getName() + ".tmp");
            try (FileOutputStream output = new FileOutputStream(temporary)) {
                output.write(bytes);
                output.flush();
                output.getFD().sync();
            }
            if (target.exists() && !target.delete()) return;
            if (!temporary.renameTo(target)) temporary.delete();
        } catch (Exception ignored) {
            // A failed snapshot write never affects live rendering or provider polling.
        }
    }

    private Snapshot read(Signal.Layer layer) {
        File source = fileFor(layer);
        if (!source.isFile() || source.length() <= 0L || source.length() > MAX_FILE_BYTES) {
            return null;
        }
        try (FileInputStream input = new FileInputStream(source)) {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[16 * 1024];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_FILE_BYTES) return null;
                output.write(buffer, 0, read);
            }
            JSONObject root = new JSONObject(
                    new String(output.toByteArray(), StandardCharsets.UTF_8));
            if (root.optInt("format", 0) != FORMAT_VERSION
                    || !layer.name().equals(root.optString("layer", ""))) return null;
            long savedAt = root.optLong("savedAt", 0L);
            if (savedAt <= 0L
                    || System.currentTimeMillis() - savedAt > restoreAgeMs(layer)) return null;
            JSONArray values = root.optJSONArray("signals");
            List<Signal> signals = new ArrayList<>();
            int cap = snapshotCap(layer);
            if (values != null) {
                for (int index = 0; index < values.length() && signals.size() < cap; index++) {
                    Signal signal = fromJson(values.optJSONObject(index));
                    if (signal != null && signal.layer == layer) signals.add(signal);
                }
            }
            if (signals.isEmpty()) return null;
            int providerCount = Math.max(signals.size(), root.optInt("providerCount", 0));
            FeedStatus status = new FeedStatus(FeedStatus.State.CACHED, providerCount,
                    "Restored last-known operations snapshot • "
                            + root.optString("providerMessage", "previous successful update"),
                    savedAt);
            return new Snapshot(layer, Collections.unmodifiableList(signals), status, savedAt);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static JSONObject toJson(Signal signal) throws Exception {
        JSONObject value = new JSONObject();
        value.put("id", signal.id);
        value.put("layer", signal.layer.name());
        value.put("title", signal.title);
        value.put("summary", signal.summary);
        putFinite(value, "latitude", signal.latitude);
        putFinite(value, "longitude", signal.longitude);
        putFinite(value, "heading", signal.heading);
        putFinite(value, "speed", signal.speedMetersPerSecond);
        value.put("timestamp", signal.timestampMs);
        value.put("source", signal.source);
        value.put("sourceUrl", signal.sourceUrl);
        value.put("credibility", signal.credibility.name());
        value.put("eventType", signal.eventType);
        value.put("region", signal.region);
        value.put("severity", signal.severity);
        JSONObject facts = new JSONObject();
        for (Map.Entry<String, String> fact : signal.facts.entrySet()) {
            facts.put(fact.getKey(), fact.getValue());
        }
        value.put("facts", facts);
        return value;
    }

    private static void putFinite(JSONObject target, String key, double number)
            throws Exception {
        target.put(key, Double.isNaN(number) || Double.isInfinite(number)
                ? JSONObject.NULL : number);
    }

    private static Signal fromJson(JSONObject value) {
        if (value == null) return null;
        try {
            Signal.Layer layer = Signal.Layer.valueOf(value.getString("layer"));
            Signal.Credibility credibility = Signal.Credibility.valueOf(
                    value.optString("credibility", Signal.Credibility.UNVERIFIED.name()));
            Map<String, String> facts = new LinkedHashMap<>();
            JSONObject factObject = value.optJSONObject("facts");
            if (factObject != null) {
                java.util.Iterator<String> keys = factObject.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    facts.put(key, factObject.optString(key, ""));
                }
            }
            return new Signal(
                    value.getString("id"), layer,
                    value.optString("title", "UNTITLED SIGNAL"),
                    value.optString("summary", ""),
                    value.optDouble("latitude", Double.NaN),
                    value.optDouble("longitude", Double.NaN),
                    value.optDouble("heading", Double.NaN),
                    value.optDouble("speed", Double.NaN),
                    value.optLong("timestamp", 0L),
                    value.optString("source", "Unknown source"),
                    value.optString("sourceUrl", ""), credibility,
                    value.optString("eventType", "OTHER"),
                    value.optString("region", "GLOBAL"),
                    value.optInt("severity", 1), facts);
        } catch (Exception ignored) {
            return null;
        }
    }

    private File fileFor(Signal.Layer layer) {
        return new File(directory, layer.name().toLowerCase(java.util.Locale.ROOT) + ".json");
    }

    private static int snapshotCap(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS:
            case SHIPS: return 2_500;
            case NEWS:
            case NATURAL: return 400;
            case AIRSPACE: return 400;
            case SATELLITES: return 700;
            case INFRASTRUCTURE:
            case WEBCAMS:
            case RADIO:
            case TV: return 1_200;
            default: return 300;
        }
    }

    private static long restoreAgeMs(Signal.Layer layer) {
        switch (layer) {
            case FLIGHTS: return 25L * 60L * 1000L;
            case SHIPS: return 2L * 60L * 60L * 1000L;
            case AIRSPACE: return 12L * 60L * 60L * 1000L;
            case SATELLITES: return 3L * 60L * 60L * 1000L;
            case NEWS: return 24L * 60L * 60L * 1000L;
            case NATURAL:
            case SPACE_WEATHER: return 7L * 24L * 60L * 60L * 1000L;
            case MARKETS: return 2L * 24L * 60L * 60L * 1000L;
            default: return 14L * 24L * 60L * 60L * 1000L;
        }
    }

    private static long snapshotWriteIntervalMs(Signal.Layer layer) {
        if (layer == Signal.Layer.FLIGHTS || layer == Signal.Layer.SHIPS) return 30_000L;
        if (layer == Signal.Layer.NEWS || layer == Signal.Layer.NATURAL) return 60_000L;
        if (layer == Signal.Layer.AIRSPACE) return 5L * 60L * 1000L;
        if (layer == Signal.Layer.SATELLITES) return 2L * 60L * 1000L;
        return 5L * 60L * 1000L;
    }
}
