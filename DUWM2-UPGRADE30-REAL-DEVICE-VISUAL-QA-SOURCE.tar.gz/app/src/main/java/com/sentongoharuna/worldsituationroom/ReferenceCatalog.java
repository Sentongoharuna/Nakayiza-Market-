package com.sentongoharuna.worldsituationroom;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * A deliberately small, clearly labelled strategic reference layer. These points provide
 * geographic context while network feeds are warming up; they are never represented as live
 * incidents, closures, threats or vessel observations.
 */
public final class ReferenceCatalog {
    private static final String EIA_SOURCE =
            "https://www.eia.gov/international/analysis/special-topics/World_Oil_Transit_Chokepoints";
    private static final String OURAIRPORTS_SOURCE = "https://ourairports.com/data/";
    private static final String PORT_SOURCE = "https://msi.nga.mil/Publications/WPI";

    private static final Entry[] ENTRIES = {
            new Entry("hormuz", "STRAIT OF HORMUZ", 26.5667d, 56.2500d,
                    "MIDDLE EAST", "Maritime energy transit reference"),
            new Entry("malacca", "STRAIT OF MALACCA", 2.5000d, 101.0000d,
                    "ASIA", "Maritime energy transit reference"),
            new Entry("suez", "SUEZ CANAL", 30.4500d, 32.3500d,
                    "AFRICA", "Inter-oceanic canal reference"),
            new Entry("bab-el-mandeb", "BAB EL-MANDEB", 12.5833d, 43.3333d,
                    "MIDDLE EAST", "Maritime energy transit reference"),
            new Entry("bosphorus", "TURKISH STRAITS", 41.1200d, 29.0700d,
                    "EUROPE", "Maritime energy transit reference"),
            new Entry("danish", "DANISH STRAITS", 55.6500d, 12.7000d,
                    "EUROPE", "Maritime energy transit reference"),
            new Entry("panama", "PANAMA CANAL", 9.0800d, -79.6800d,
                    "AMERICAS", "Inter-oceanic canal reference"),
            new Entry("lombok", "LOMBOK STRAIT", -8.5000d, 115.7000d,
                    "ASIA", "Alternative maritime transit reference"),
            new Entry("sunda", "SUNDA STRAIT", -5.9000d, 105.9000d,
                    "ASIA", "Alternative maritime transit reference"),
            new Entry("cape", "CAPE OF GOOD HOPE ROUTE", -34.3581d, 18.4719d,
                    "AFRICA", "Alternative long-haul maritime route reference")
    };

    private static final Hub[] AIRPORTS = {
            hub("ebb", "ENTEBBE INTERNATIONAL / EBB HUEN", 0.0424, 32.4435, "AFRICA", "Uganda"),
            hub("nbo", "JOMO KENYATTA / NBO HKJK", -1.3192, 36.9278, "AFRICA", "Kenya"),
            hub("add", "ADDIS ABABA BOLE / ADD HAAB", 8.9779, 38.7993, "AFRICA", "Ethiopia"),
            hub("jnb", "O.R. TAMBO / JNB FAOR", -26.1337, 28.2420, "AFRICA", "South Africa"),
            hub("cpt", "CAPE TOWN / CPT FACT", -33.9648, 18.6017, "AFRICA", "South Africa"),
            hub("cai", "CAIRO INTERNATIONAL / CAI HECA", 30.1219, 31.4056, "AFRICA", "Egypt"),
            hub("los", "MURTALA MUHAMMED / LOS DNMM", 6.5774, 3.3212, "AFRICA", "Nigeria"),
            hub("dxb", "DUBAI INTERNATIONAL / DXB OMDB", 25.2532, 55.3657, "MIDDLE EAST", "United Arab Emirates"),
            hub("doh", "HAMAD INTERNATIONAL / DOH OTHH", 25.2731, 51.6081, "MIDDLE EAST", "Qatar"),
            hub("ist", "ISTANBUL / IST LTFM", 41.2753, 28.7519, "EUROPE", "Türkiye"),
            hub("lhr", "LONDON HEATHROW / LHR EGLL", 51.4700, -0.4543, "EUROPE", "United Kingdom"),
            hub("cdg", "PARIS CHARLES DE GAULLE / CDG LFPG", 49.0097, 2.5479, "EUROPE", "France"),
            hub("fra", "FRANKFURT / FRA EDDF", 50.0379, 8.5622, "EUROPE", "Germany"),
            hub("jfk", "NEW YORK JFK / JFK KJFK", 40.6413, -73.7781, "AMERICAS", "United States"),
            hub("atl", "ATLANTA HARTSFIELD-JACKSON / ATL KATL", 33.6407, -84.4277, "AMERICAS", "United States"),
            hub("lax", "LOS ANGELES / LAX KLAX", 33.9416, -118.4085, "AMERICAS", "United States"),
            hub("gru", "SÃO PAULO GUARULHOS / GRU SBGR", -23.4356, -46.4731, "AMERICAS", "Brazil"),
            hub("mex", "MEXICO CITY / MEX MMMX", 19.4361, -99.0719, "AMERICAS", "Mexico"),
            hub("sin", "SINGAPORE CHANGI / SIN WSSS", 1.3644, 103.9915, "ASIA", "Singapore"),
            hub("hkg", "HONG KONG / HKG VHHH", 22.3080, 113.9185, "ASIA", "Hong Kong"),
            hub("hnd", "TOKYO HANEDA / HND RJTT", 35.5494, 139.7798, "ASIA", "Japan"),
            hub("icn", "SEOUL INCHEON / ICN RKSI", 37.4602, 126.4407, "ASIA", "South Korea"),
            hub("del", "DELHI INDIRA GANDHI / DEL VIDP", 28.5562, 77.1000, "ASIA", "India"),
            hub("syd", "SYDNEY KINGSFORD SMITH / SYD YSSY", -33.9399, 151.1753, "OCEANIA", "Australia")
    };

    private static final Hub[] PORTS = {
            hub("mombasa", "PORT OF MOMBASA", -4.0435, 39.6682, "AFRICA", "Kenya"),
            hub("dar", "PORT OF DAR ES SALAAM", -6.8227, 39.2894, "AFRICA", "Tanzania"),
            hub("durban", "PORT OF DURBAN", -29.8711, 31.0269, "AFRICA", "South Africa"),
            hub("djibouti", "PORT OF DJIBOUTI", 11.5940, 43.1480, "AFRICA", "Djibouti"),
            hub("tema", "PORT OF TEMA", 5.6265, 0.0118, "AFRICA", "Ghana"),
            hub("lagos", "LAGOS / APAPA PORT", 6.4483, 3.3631, "AFRICA", "Nigeria"),
            hub("jebelali", "JEBEL ALI PORT", 24.9857, 55.0273, "MIDDLE EAST", "United Arab Emirates"),
            hub("haifa", "PORT OF HAIFA", 32.8192, 34.9983, "MIDDLE EAST", "Israel"),
            hub("rotterdam", "PORT OF ROTTERDAM", 51.9480, 4.1420, "EUROPE", "Netherlands"),
            hub("antwerp", "PORT OF ANTWERP-BRUGES", 51.2636, 4.4000, "EUROPE", "Belgium"),
            hub("hamburg", "PORT OF HAMBURG", 53.5461, 9.9661, "EUROPE", "Germany"),
            hub("piraeus", "PORT OF PIRAEUS", 37.9420, 23.6460, "EUROPE", "Greece"),
            hub("singapore", "PORT OF SINGAPORE", 1.2644, 103.8400, "ASIA", "Singapore"),
            hub("shanghai", "PORT OF SHANGHAI", 31.2304, 121.4910, "ASIA", "China"),
            hub("ningbo", "NINGBO-ZHOUSHAN PORT", 29.8683, 121.5440, "ASIA", "China"),
            hub("busan", "PORT OF BUSAN", 35.1028, 129.0403, "ASIA", "South Korea"),
            hub("colombo", "PORT OF COLOMBO", 6.9497, 79.8416, "ASIA", "Sri Lanka"),
            hub("mumbai", "MUMBAI PORT", 18.9500, 72.8500, "ASIA", "India"),
            hub("losangeles", "PORT OF LOS ANGELES", 33.7405, -118.2728, "AMERICAS", "United States"),
            hub("newyork", "PORT OF NEW YORK / NEW JERSEY", 40.6681, -74.0450, "AMERICAS", "United States"),
            hub("santos", "PORT OF SANTOS", -23.9608, -46.3336, "AMERICAS", "Brazil"),
            hub("balboa", "PORT OF BALBOA / PANAMA", 8.9525, -79.5667, "AMERICAS", "Panama"),
            hub("sydneyport", "PORT BOTANY / SYDNEY", -33.9800, 151.2200, "OCEANIA", "Australia")
    };

    private ReferenceCatalog() {}

    public static List<Signal> signals(long indexedAtMs) {
        List<Signal> values = new ArrayList<>();
        SimpleDateFormat utc = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);
        utc.setTimeZone(TimeZone.getTimeZone("UTC"));
        String indexed = utc.format(new java.util.Date(indexedAtMs));
        for (Entry entry : ENTRIES) {
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("REFERENCE TYPE", entry.kind);
            facts.put("LIVE STATUS", "Not asserted — reference point only");
            facts.put("INDEXED AT", indexed);
            facts.put("TIMESTAMP TYPE", "Local reference-index time, not an incident time");
            facts.put("MAP USE", "Context for nearby public-source signals and traffic");
            facts.put("CATEGORY", "MARITIME CORRIDOR");
            values.add(new Signal(
                    "reference-" + entry.id,
                    Signal.Layer.INFRASTRUCTURE,
                    entry.title,
                    "Static public geographic context. This marker does not indicate an outage, "
                            + "closure, conflict or current traffic condition.",
                    entry.latitude,
                    entry.longitude,
                    Double.NaN,
                    indexedAtMs,
                    "U.S. Energy Information Administration",
                    EIA_SOURCE,
                    Signal.Credibility.PUBLIC_SOURCE,
                    "REFERENCE",
                    entry.region,
                    1,
                    facts));
        }
        for (Hub hub : AIRPORTS) {
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("CATEGORY", "AIRPORT / RUNWAY REFERENCE");
            facts.put("COUNTRY", hub.country);
            facts.put("LIVE STATUS", "Not asserted — reference point only");
            facts.put("RUNWAY DETAIL", "Nightly OurAirports atlas joins when available");
            facts.put("INDEXED AT", indexed);
            values.add(new Signal("airport-reference-" + hub.id,
                    Signal.Layer.INFRASTRUCTURE, hub.title,
                    "Public airport reference. This marker does not assert delay, closure, "
                            + "traffic level or runway availability.",
                    hub.latitude, hub.longitude, Double.NaN, indexedAtMs,
                    "OurAirports public-domain data", OURAIRPORTS_SOURCE,
                    Signal.Credibility.PUBLIC_SOURCE, "INFRASTRUCTURE", hub.region, 1, facts));
        }
        for (Hub hub : PORTS) {
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("CATEGORY", "PORT REFERENCE");
            facts.put("COUNTRY", hub.country);
            facts.put("LIVE STATUS", "Not asserted — reference point only");
            facts.put("INDEXED AT", indexed);
            values.add(new Signal("port-reference-" + hub.id,
                    Signal.Layer.INFRASTRUCTURE, hub.title,
                    "Public port reference. This marker does not assert congestion, closure, "
                            + "security condition or vessel presence.",
                    hub.latitude, hub.longitude, Double.NaN, indexedAtMs,
                    "NGA World Port Index reference", PORT_SOURCE,
                    Signal.Credibility.PUBLIC_SOURCE, "INFRASTRUCTURE", hub.region, 1, facts));
        }
        return values;
    }

    private static Hub hub(String id, String title, double latitude, double longitude,
                           String region, String country) {
        return new Hub(id, title, latitude, longitude, region, country);
    }

    private static final class Entry {
        final String id;
        final String title;
        final double latitude;
        final double longitude;
        final String region;
        final String kind;

        Entry(String id, String title, double latitude, double longitude,
              String region, String kind) {
            this.id = id;
            this.title = title;
            this.latitude = latitude;
            this.longitude = longitude;
            this.region = region;
            this.kind = kind;
        }
    }

    private static final class Hub {
        final String id;
        final String title;
        final double latitude;
        final double longitude;
        final String region;
        final String country;

        Hub(String id, String title, double latitude, double longitude,
            String region, String country) {
            this.id = id;
            this.title = title;
            this.latitude = latitude;
            this.longitude = longitude;
            this.region = region;
            this.country = country;
        }
    }
}
