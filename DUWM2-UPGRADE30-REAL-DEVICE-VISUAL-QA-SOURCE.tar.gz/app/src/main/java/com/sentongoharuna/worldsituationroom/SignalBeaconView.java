package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;

import java.util.Locale;

/**
 * Compact operational signal legend. Lights are normally steady and only pulse when a
 * matching real feed update arrives; green, amber and red intentionally use different
 * rhythms so colour is not the only cue.
 */
public final class SignalBeaconView extends View {
    public static final int GREEN = 0;
    public static final int AMBER = 1;
    public static final int RED = 2;

    private static final int[] COLORS = {
            Color.rgb(75, 166, 124),
            Color.rgb(199, 151, 68),
            Color.rgb(219, 73, 80)
    };
    private static final String[] LABELS = {"ONLINE", "DEVELOPING", "PRIORITY"};
    private static final String[] COMPACT_LABELS = {"ON", "DEV", "PRI"};
    private static final long[] DURATIONS_MS = {1_150L, 1_850L, 2_650L};

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] counts = new int[3];
    private final long[] pulseStartedMs = {-10_000L, -10_000L, -10_000L};

    public SignalBeaconView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        textPaint.setTypeface(android.graphics.Typeface.MONOSPACE);
        setContentDescription("Signal lights: green online, amber developing, red priority");
    }

    public void setCounts(int online, int developing, int priority) {
        counts[GREEN] = Math.max(0, online);
        counts[AMBER] = Math.max(0, developing);
        counts[RED] = Math.max(0, priority);
        setContentDescription(String.format(Locale.US,
                "Signal lights: green online %d, amber developing %d, red priority %d",
                counts[GREEN], counts[AMBER], counts[RED]));
        invalidate();
    }

    /** Starts one independent, finite pulse caused by a real update. */
    public void pulse(int channel) {
        if (channel < GREEN || channel > RED) return;
        pulseStartedMs[channel] = SystemClock.uptimeMillis();
        postInvalidateOnAnimation();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = SystemClock.uptimeMillis();
        float density = getResources().getDisplayMetrics().density;
        float scaledDensity = getResources().getDisplayMetrics().scaledDensity;
        float section = getWidth() / 3f;
        float centerY = getHeight() / 2f;
        boolean animating = false;

        for (int index = 0; index < 3; index++) {
            float left = index * section;
            boolean compact = section < 82f * density;
            float dotX = left + (compact ? 5f : 11f) * density;
            long elapsed = now - pulseStartedMs[index];
            boolean active = elapsed >= 0L && elapsed < DURATIONS_MS[index];
            float beat = 0f;
            if (active) {
                animating = true;
                float progress = elapsed / (float) DURATIONS_MS[index];
                int repetitions = index == GREEN ? 1 : index == AMBER ? 2 : 3;
                beat = (float) Math.abs(Math.sin(progress * Math.PI * repetitions));
                float ringRadius = (4f + progress * (index == RED ? 11f : 8f)) * density;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth((1.2f + beat) * density);
                int color = COLORS[index];
                paint.setColor(Color.argb((int) (115f * beat),
                        Color.red(color), Color.green(color), Color.blue(color)));
                canvas.drawCircle(dotX, centerY, ringRadius, paint);
            }

            int color = COLORS[index];
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(active ? (int) (175 + beat * 60) : 170,
                    Color.red(color), Color.green(color), Color.blue(color)));
            canvas.drawCircle(dotX, centerY, (2.8f + beat * 1.2f) * density, paint);

            textPaint.setTextSize((compact ? 6.2f : 7.4f) * scaledDensity);
            textPaint.setColor(Color.argb(235, 196, 204, 211));
            textPaint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText((compact ? COMPACT_LABELS[index] : LABELS[index])
                            + " " + counts[index],
                    dotX + (compact ? 5f : 8f) * density,
                    centerY + 2.7f * density, textPaint);

            if (index < 2) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Math.max(1f, 0.5f * density));
                paint.setColor(Color.argb(70, 64, 75, 86));
                canvas.drawLine(left + section - 2f * density, 4f * density,
                        left + section - 2f * density, getHeight() - 4f * density, paint);
            }
        }

        if (animating && isAttachedToWindow()) postInvalidateOnAnimation();
    }
}
