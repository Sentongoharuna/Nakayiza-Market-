package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuAlertEngine{
 static final String P="duwm_alert_seen_v1";static final long WINDOW=6L*60L*60L*1000L;
 public static void inspect(Context c,Signal.Layer layer,List<Signal> values){if(values==null)return;android.content.SharedPreferences p=c.getSharedPreferences(P,0);long now=System.currentTimeMillis();for(Signal s:values){if(s==null||s.severity<4)continue;String k=layer.name()+":"+s.id;long seen=p.getLong(k,0);if(now-seen<WINDOW)continue;p.edit().putLong(k,now).apply();DuNotificationCenter.post(c,s,"PRIORITY "+s.severity+" · "+s.eventType);}}
}