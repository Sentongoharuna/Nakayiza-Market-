package com.sentongoharuna.worldsituationroom;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Non-secret app preferences and configurable RSS list. */
public final class AppPreferences {
    private static final String STORE = "wsr_preferences";
    private static final String CUSTOM_RSS = "custom_rss";
    private final SharedPreferences preferences;

    public AppPreferences(Context context) {
        preferences = context.getApplicationContext()
                .getSharedPreferences(STORE, Context.MODE_PRIVATE);
    }

    public String customRss() {
        return SafePreferences.string(preferences, CUSTOM_RSS, "");
    }

    public void setCustomRss(String value) {
        preferences.edit().putString(CUSTOM_RSS, value == null ? "" : value.trim()).apply();
    }

    public List<String> rssFeeds() {
        Set<String> result = new LinkedHashSet<>();
        for (String feed : AppConfig.DEFAULT_RSS) {
            result.add(feed);
        }
        for (String line : customRss().split("[\\r\\n,]+")) {
            String clean = line.trim();
            if (clean.startsWith("https://")) {
                result.add(clean);
            }
        }
        return new ArrayList<>(result);
    }
}
