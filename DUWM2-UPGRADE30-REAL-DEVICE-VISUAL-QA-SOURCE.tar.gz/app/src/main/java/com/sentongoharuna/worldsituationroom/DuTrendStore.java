package com.sentongoharuna.worldsituationroom;
import android.content.*;import org.json.*;import java.util.*;
public final class DuTrendStore{
 static final String P="duwm_trends_v1";static final int MAX=72;
 public static synchronized void record(Context c,String key,double value){if(Double.isNaN(value)||Double.isInfinite(value))return;android.content.SharedPreferences p=c.getSharedPreferences(P,0);try{JSONArray a=new JSONArray(p.getString(key,"[]"));JSONObject x=new JSONObject();x.put("t",System.currentTimeMillis());x.put("v",value);a.put(x);JSONArray b=new JSONArray();for(int i=Math.max(0,a.length()-MAX);i<a.length();i++)b.put(a.get(i));p.edit().putString(key,b.toString()).apply();}catch(Exception ignored){}}
 public static double[] values(Context c,String key){try{JSONArray a=new JSONArray(c.getSharedPreferences(P,0).getString(key,"[]"));double[]v=new double[a.length()];for(int i=0;i<a.length();i++)v[i]=a.getJSONObject(i).getDouble("v");return v;}catch(Exception e){return new double[0];}}
}