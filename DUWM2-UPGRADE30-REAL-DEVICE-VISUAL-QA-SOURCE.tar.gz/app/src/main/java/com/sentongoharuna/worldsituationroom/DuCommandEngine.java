package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuCommandEngine{
 final DuLiveRepository repo;public DuCommandEngine(Context c){repo=new DuLiveRepository(c);}
 public List<Signal> run(DuCommandQuery q){List<Signal> pool=new ArrayList<>();if("GLOBE".equals(q.system))for(String s:new String[]{"AIR","SEA","ORBIT","WX","EVENTS","NEWS"})pool.addAll(repo.signals(s));else pool.addAll(repo.signals(q.system));long now=System.currentTimeMillis();List<Signal> out=new ArrayList<>();
  for(Signal s:pool){if(!q.id.isEmpty()&&!s.id.toLowerCase(Locale.ROOT).contains(q.id.toLowerCase(Locale.ROOT)))continue;if(q.windowMs>0&&now-s.timestampMs>q.windowMs)continue;String hay=(s.title+" "+s.summary+" "+s.region+" "+s.eventType+" "+s.source).toLowerCase(Locale.ROOT);if(!q.place.isEmpty()&&!hay.contains(q.place.toLowerCase(Locale.ROOT)))continue;if(!q.text.isEmpty()){boolean ok=true;for(String x:q.text.split(" "))if(x.length()>2&&!hay.contains(x)){ok=false;break;}if(!ok)continue;}out.add(s);}
  Collections.sort(out,(a,b)->Long.compare(b.timestampMs,a.timestampMs));return out.subList(0,Math.min(60,out.size()));}
}