package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.os.*;import android.text.*;import android.widget.*;import java.util.*;
public final class DuSystemIndexActivity extends Activity{
 String sys,filter="LIVE";LinearLayout list;EditText search;DuLiveRepository repo;
 public void onCreate(Bundle b){super.onCreate(b);sys=getIntent().getStringExtra("system");if(sys==null)sys=DuSessionState.indexSystem(this);filter=DuSessionState.indexFilter(this);repo=new DuLiveRepository(this);DuSessionState.page(this,sys+" INDEX");
  LinearLayout r=Du2Ui.shell(this,sys+" SOURCE INDEX");r.addView(DuLiveCounterStrip.make(this));r.addView(DuBreadcrumb.make(this,"GLOBE",sys,"INDEX"));r.addView(DuChronoNav.bar(this,sys+" INDEX","", ""));
  search=new EditText(this);search.setText(DuSessionState.indexQuery(this));search.setHint("Search real "+sys+" provider records");search.setTextColor(Du2Ui.FG);search.setHintTextColor(Du2Ui.M);search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){DuSessionState.index(DuSystemIndexActivity.this,sys,filter,s.toString());render();}public void afterTextChanged(Editable e){}});r.addView(search);
  LinearLayout chips=new LinearLayout(this);for(String q:new String[]{"LIVE","RECENT","SOURCE","PLACE"}){Button x=Du2Ui.button(this,q);x.setOnClickListener(v->{filter=q;DuSessionState.index(this,sys,filter,search.getText().toString());render();});chips.addView(x,new LinearLayout.LayoutParams(0,48,1));}HorizontalScrollView chipScroll=new HorizontalScrollView(this);chipScroll.addView(chips);r.addView(chipScroll);
  ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);r.addView(sc,new LinearLayout.LayoutParams(-1,0,1));render();setContentView(r);
 }
 void render(){list.removeAllViews();List<Signal> all=repo.signals(sys);list.addView(Du2Ui.panel(this,"LIVE PROVIDER SNAPSHOT","● "+repo.status(sys),"COUNT "+repo.count(sys)+" · AGE "+repo.age(sys)+" · "+(all.isEmpty()?"No last-good provider snapshot yet":"Bound to preserved provider records")));
  String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);int shown=0;
  for(Signal s:all){String hay=(s.title+" "+s.summary+" "+s.source+" "+s.region+" "+s.eventType).toLowerCase(Locale.ROOT);if(!q.isEmpty()&&!hay.contains(q))continue;if("SOURCE".equals(filter)&&s.source.trim().isEmpty())continue;if("PLACE".equals(filter)&&!s.hasLocation())continue;list.addView(DuProviderRecordView.make(this,s));if(++shown>=(DuPerformancePolicy.lowMemory(this)?40:80))break;}
  if(shown==0)list.addView(Du2Ui.panel(this,"NO PROVIDER RECORDS","● "+repo.status(sys),"The preserved live engine has not saved a usable "+sys+" snapshot yet. Open the live index or retry the provider; no fake rows are created."));
  Button live=Du2Ui.button(this,"OPEN PRESERVED LIVE "+sys+" ENGINE");live.setOnClickListener(v->startActivity(DuFlow.sources(this,sys)));list.addView(live);
 }
 protected void onResume(){super.onResume();if(list!=null)render();}
}