package com.sentongoharuna.worldsituationroom;
import android.content.*;import android.graphics.*;import android.view.*;import java.util.*;
public final class DuMiniMapView extends View{
 final Paint p=new Paint(1);final String id;double lat=Double.NaN,lon=Double.NaN;List<DuTrackHistoryStore.Fix> trail=Collections.emptyList();
 public DuMiniMapView(Context c,String id){super(c);this.id=id;setMinimumHeight(dp(180));setContentDescription("Mini map for "+id);reload();}
 public void setPosition(double a,double o){lat=a;lon=o;invalidate();}
 public void reload(){trail=DuTrackHistoryStore.load(getContext(),id);if(!trail.isEmpty()){DuTrackHistoryStore.Fix f=trail.get(trail.size()-1);lat=f.lat;lon=f.lon;}invalidate();}
 protected void onDraw(Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight();c.drawColor(Color.rgb(5,12,17));p.setStrokeWidth(dp(1));p.setColor(Color.rgb(32,60,72));for(int i=1;i<6;i++){float x=w*i/6f,y=h*i/6f;c.drawLine(x,0,x,h,p);c.drawLine(0,y,w,y,p);}
  if(Double.isNaN(lat)||Double.isNaN(lon)){p.setColor(Color.LTGRAY);p.setTextSize(dp(12));c.drawText("NO SOURCE COORDINATES",dp(14),h/2f,p);return;}
  double span=chooseSpan();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.rgb(72,190,214));float px=0,py=0;boolean first=true;
  for(DuTrackHistoryStore.Fix f:trail){float x=x(f.lon,span,w),y=y(f.lat,span,h);if(first){first=false;}else c.drawLine(px,py,x,y,p);px=x;py=y;}
  p.setStyle(Paint.Style.FILL);float cx=x(lon,span,w),cy=y(lat,span,h);p.setColor(Color.rgb(78,190,132));c.drawCircle(cx,cy,dp(6),p);p.setStyle(Paint.Style.STROKE);p.setColor(Color.WHITE);c.drawCircle(cx,cy,dp(10),p);
  p.setStyle(Paint.Style.FILL);p.setColor(Color.LTGRAY);p.setTextSize(dp(10));c.drawText(String.format(Locale.US,"%.5f, %.5f · ±%.0f km",lat,lon,span*111d),dp(10),h-dp(10),p);
 }
 double chooseSpan(){double s=.25;for(DuTrackHistoryStore.Fix f:trail)s=Math.max(s,Math.max(Math.abs(f.lat-lat),Math.abs(f.lon-lon))*1.35);return Math.min(25,s);}
 float x(double o,double s,int w){return(float)(w/2d+(o-lon)/s*w/2d);}float y(double a,double s,int h){return(float)(h/2d-(a-lat)/s*h/2d);}int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
}