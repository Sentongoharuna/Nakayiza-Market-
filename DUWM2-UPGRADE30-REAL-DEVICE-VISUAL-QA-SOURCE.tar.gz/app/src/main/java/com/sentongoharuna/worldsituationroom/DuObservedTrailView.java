package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;
public final class DuObservedTrailView{
 public static View make(Activity a,String id){LinearLayout c=Du2Ui.panel(a,"OBSERVED PROVIDER FIX TRAIL","● REAL FIXES","Only coordinates received from the provider are listed; no estimated point is presented as an observation.");
  List<DuTrackHistoryStore.Fix> f=DuTrackHistoryStore.load(a,id);int start=Math.max(0,f.size()-8);SimpleDateFormat d=new SimpleDateFormat("HH:mm:ss",Locale.US);
  for(int i=start;i<f.size();i++){DuTrackHistoryStore.Fix x=f.get(i);TextView v=Du2Ui.t(a,String.format(Locale.US,"%02d  %.5f, %.5f  ·  %s",i+1,x.lat,x.lon,d.format(new Date(x.time))),9);v.setTextColor(Du2Ui.C);c.addView(v);}
  if(f.isEmpty())c.addView(Du2Ui.t(a,"WAITING FOR THE NEXT PROVIDER FIX",9));
  else c.addView(Du2Ui.t(a,"FIXES "+f.size()+" · TRAIL UPDATES ON EACH LIVE PROVIDER CALLBACK",9));
  return c;
 }
}