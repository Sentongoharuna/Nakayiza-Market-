package com.sentongoharuna.worldsituationroom;
import android.content.*;
public final class DuSessionState{
 static final String P="duwm_session_v1";
 public static void page(Context c,String page){c.getSharedPreferences(P,0).edit().putString("page",safe(page,"GLOBE")).apply();}
 public static String page(Context c){return c.getSharedPreferences(P,0).getString("page","GLOBE");}
 public static void index(Context c,String system,String filter,String query){c.getSharedPreferences(P,0).edit().putString("index_system",safe(system,"AIR")).putString("index_filter",safe(filter,"LIVE")).putString("index_query",safe(query,"")).apply();}
 public static String indexSystem(Context c){return c.getSharedPreferences(P,0).getString("index_system","AIR");}
 public static String indexFilter(Context c){return c.getSharedPreferences(P,0).getString("index_filter","LIVE");}
 public static String indexQuery(Context c){return c.getSharedPreferences(P,0).getString("index_query","");}
 public static void clearTransient(Context c){c.getSharedPreferences(P,0).edit().remove("index_query").apply();}
 static String safe(String s,String d){return s==null?d:s;}
}