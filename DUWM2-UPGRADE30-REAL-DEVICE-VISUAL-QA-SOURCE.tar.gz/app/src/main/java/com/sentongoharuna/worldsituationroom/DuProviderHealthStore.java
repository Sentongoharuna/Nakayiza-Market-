package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuProviderHealthStore{
 static final String P="duwm_provider_health_v2";
 public static void record(Context c,Signal.Layer l,FeedStatus s){if(l==null||s==null)return;android.content.SharedPreferences p=c.getSharedPreferences(P,0);String k=l.name();android.content.SharedPreferences.Editor e=p.edit().putString(k+":state",s.state.name()).putInt(k+":count",s.count).putString(k+":message",s.message).putLong(k+":updated",s.updatedAtMs).putLong(k+":seen",System.currentTimeMillis());if(s.state==FeedStatus.State.LIVE||s.state==FeedStatus.State.READY)e.putLong(k+":success",s.updatedAtMs);if(s.state==FeedStatus.State.OFFLINE||s.state==FeedStatus.State.KEY_REQUIRED)e.putLong(k+":failure",System.currentTimeMillis());e.apply();}
 public static String state(Context c,String s){Signal.Layer l=DuLiveRepository.layer(s);return l==null?"UNKNOWN":c.getSharedPreferences(P,0).getString(l.name()+":state","UNKNOWN");}
 public static int count(Context c,String s){Signal.Layer l=DuLiveRepository.layer(s);return l==null?0:c.getSharedPreferences(P,0).getInt(l.name()+":count",0);}
 public static String message(Context c,String s){Signal.Layer l=DuLiveRepository.layer(s);return l==null?"":c.getSharedPreferences(P,0).getString(l.name()+":message","");}
 public static long success(Context c,String s){Signal.Layer l=DuLiveRepository.layer(s);return l==null?0:c.getSharedPreferences(P,0).getLong(l.name()+":success",0);}
 public static long failure(Context c,String s){Signal.Layer l=DuLiveRepository.layer(s);return l==null?0:c.getSharedPreferences(P,0).getLong(l.name()+":failure",0);}
 public static String age(long t){if(t<=0)return"—";long sec=Math.max(0,(System.currentTimeMillis()-t)/1000);return sec<60?sec+"s":sec<3600?(sec/60)+"m":(sec/3600)+"h";}
}