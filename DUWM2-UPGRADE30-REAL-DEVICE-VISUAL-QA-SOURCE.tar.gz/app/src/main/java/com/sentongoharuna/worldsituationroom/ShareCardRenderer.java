package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Creates a local 4:5 newsroom PNG and opens Android's native share sheet. */
public final class ShareCardRenderer {
    private static final int WIDTH = 1080;
    private static final int HEIGHT = 1350;
    private static final int BG = Color.rgb(5, 8, 12);
    private static final int PANEL = Color.rgb(12, 18, 25);
    private static final int TEXT = Color.rgb(235, 241, 244);
    private static final int MUTED = Color.rgb(146, 164, 176);
    private static final int LINE = Color.rgb(42, 59, 72);
    private static final ExecutorService RENDERER = Executors.newSingleThreadExecutor();

    private ShareCardRenderer() { }

    public static void share(Activity activity, ShareCardData data) {
        if (activity == null || data == null || activity.isFinishing()) return;
        Toast.makeText(activity, "Creating share card…", Toast.LENGTH_SHORT).show();
        RENDERER.execute(() -> {
            try {
                File png = render(activity, data);
                Uri uri = new Uri.Builder()
                        .scheme("content")
                        .authority(activity.getPackageName() + ".sharecards")
                        .appendPath("card")
                        .appendPath(png.getName())
                        .build();
                String shareText = fullText(data);
                activity.runOnUiThread(() -> {
                    if (activity.isFinishing() || activity.isDestroyed()) return;
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("image/png");
                    send.putExtra(Intent.EXTRA_SUBJECT, data.title + " — " + ShareCardData.BRAND);
                    send.putExtra(Intent.EXTRA_TEXT, shareText);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.setClipData(ClipData.newRawUri("DU World Monitor share card", uri));
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try {
                        activity.startActivity(Intent.createChooser(send, "Share information card"));
                    } catch (RuntimeException error) {
                        Toast.makeText(activity, "No compatible sharing app is available",
                                Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Exception error) {
                activity.runOnUiThread(() -> Toast.makeText(activity,
                        "Could not create share card", Toast.LENGTH_LONG).show());
            }
        });
    }

    private static File render(Activity activity, ShareCardData data) throws IOException {
        Bitmap bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(BG);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setStrokeWidth(1f);
        paint.setColor(Color.argb(34, 112, 177, 201));
        for (int x = 0; x <= WIDTH; x += 90) canvas.drawLine(x, 0, x, HEIGHT, paint);
        for (int y = 0; y <= HEIGHT; y += 90) canvas.drawLine(0, y, WIDTH, y, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(246, 7, 11, 16));
        canvas.drawRoundRect(new RectF(44, 42, WIDTH - 44, HEIGHT - 42), 38, 38, paint);
        paint.setColor(data.accentColor);
        canvas.drawRoundRect(new RectF(44, 42, 58, HEIGHT - 42), 8, 8, paint);

        int left = 94;
        int right = WIDTH - 90;
        float y = 108f;
        drawBrandMark(canvas, paint, left + 30f, y - 12f, 29f);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(39f);
        paint.setColor(TEXT);
        canvas.drawText(ShareCardData.BRAND, left + 76f, y, paint);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setTextSize(18f);
        paint.setColor(Color.rgb(226, 174, 82));
        canvas.drawText("GLOBAL SIGNALS • LOCAL WITNESSES • SOURCE AWARE",
                left + 76f, y + 34f, paint);

        y += 88f;
        paint.setColor(PANEL);
        canvas.drawRoundRect(new RectF(left, y, right, y + 68f), 18, 18, paint);
        paint.setColor(data.accentColor);
        paint.setTextSize(22f);
        canvas.drawText("● " + clip(data.status, 24) + "  •  SEVERITY " + data.severity
                + "  •  " + clip(data.credibility, 40), left + 22, y + 43f, paint);

        y += 108f;
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(55f);
        paint.setColor(TEXT);
        y = drawWrapped(canvas, paint, data.title, left, y, right - left, 66f, 4);

        y += 18f;
        paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        paint.setTextSize(32f);
        paint.setColor(Color.rgb(203, 216, 224));
        y = drawWrapped(canvas, paint, data.summary, left, y, right - left, 43f, 5);

        y += 28f;
        paint.setColor(LINE);
        canvas.drawRect(left, y, right, y + 2f, paint);
        y += 32f;

        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        int shown = 0;
        boolean more = false;
        for (Map.Entry<String, String> fact : data.facts.entrySet()) {
            if (shown >= 8 || y > 1010f) {
                more = true;
                break;
            }
            paint.setTextSize(20f);
            paint.setColor(data.accentColor);
            canvas.drawText(clip(fact.getKey().toUpperCase(Locale.ROOT), 32), left, y, paint);
            y += 30f;
            paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            paint.setTextSize(28f);
            paint.setColor(TEXT);
            y = drawWrapped(canvas, paint, fact.getValue(), left, y,
                    right - left, 36f, 2);
            y += 13f;
            paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
            shown++;
        }
        if (more) {
            paint.setTextSize(20f);
            paint.setColor(MUTED);
            canvas.drawText("FULL DETAILS INCLUDED IN THE SHARED TEXT", left, 1050f, paint);
        }

        float footerTop = 1090f;
        paint.setColor(LINE);
        canvas.drawRect(left, footerTop, right, footerTop + 2f, paint);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setTextSize(21f);
        paint.setColor(MUTED);
        canvas.drawText("SOURCE", left, footerTop + 38f, paint);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(25f);
        paint.setColor(TEXT);
        canvas.drawText(clip(data.source, 62), left + 112f, footerTop + 38f, paint);

        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        paint.setTextSize(21f);
        paint.setColor(MUTED);
        canvas.drawText("UTC", left, footerTop + 76f, paint);
        canvas.drawText(utc(data.timestampMs), left + 112f, footerTop + 76f, paint);
        canvas.drawText("REGION", left, footerTop + 114f, paint);
        canvas.drawText(clip(data.region, 42), left + 112f, footerTop + 114f, paint);
        if (data.hasLocation()) {
            canvas.drawText(String.format(Locale.US, "COORD  %.4f, %.4f",
                    data.latitude, data.longitude), left, footerTop + 152f, paint);
        }

        paint.setColor(data.accentColor);
        paint.setTextSize(19f);
        paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        canvas.drawText(clip(data.disclaimer.toUpperCase(Locale.ROOT), 82),
                left, HEIGHT - 86f, paint);
        paint.setColor(MUTED);
        paint.setTextSize(17f);
        canvas.drawText("#DUWORLDMONITOR  •  " + ShareCardData.TAGLINE,
                left, HEIGHT - 55f, paint);

        File directory = new File(activity.getCacheDir(), "share-cards");
        if (!directory.exists() && !directory.mkdirs()) {
            bitmap.recycle();
            throw new IOException("Could not create share-card cache");
        }
        prune(directory);
        File file = new File(directory, "du-world-moniter-"
                + System.currentTimeMillis() + ".png");
        try (FileOutputStream output = new FileOutputStream(file)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)) {
                throw new IOException("PNG encoder failed");
            }
        } finally {
            bitmap.recycle();
        }
        return file;
    }

    private static void drawBrandMark(
            Canvas canvas,
            Paint paint,
            float centerX,
            float centerY,
            float radius) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(14, 34, 50));
        canvas.drawCircle(centerX, centerY, radius, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(2.2f);
        paint.setColor(Color.rgb(112, 213, 242));
        canvas.drawCircle(centerX, centerY, radius - 2f, paint);
        canvas.drawOval(new RectF(centerX - radius * 0.45f, centerY - radius + 2f,
                centerX + radius * 0.45f, centerY + radius - 2f), paint);
        canvas.drawLine(centerX - radius + 2f, centerY,
                centerX + radius - 2f, centerY, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(radius * 0.72f);
        paint.setColor(Color.rgb(244, 198, 111));
        canvas.drawText("DU", centerX, centerY + radius * 0.26f, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setColor(Color.rgb(230, 77, 85));
        canvas.drawCircle(centerX + radius * 0.72f,
                centerY - radius * 0.72f, radius * 0.16f, paint);
    }

    private static float drawWrapped(Canvas canvas, Paint paint, String value, float x,
                                     float y, float width, float lineHeight, int maxLines) {
        List<String> lines = wrap(paint, value, width, maxLines);
        for (String line : lines) {
            canvas.drawText(line, x, y, paint);
            y += lineHeight;
        }
        return y;
    }

    private static List<String> wrap(Paint paint, String value, float width, int maxLines) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        List<String> result = new ArrayList<>();
        String remaining = clean;
        while (!remaining.isEmpty() && result.size() < maxLines) {
            int count = paint.breakText(remaining, true, width, null);
            if (count <= 0) break;
            if (count < remaining.length()) {
                int space = remaining.lastIndexOf(' ', count);
                if (space > 0) count = space;
            }
            String line = remaining.substring(0, count).trim();
            remaining = remaining.substring(count).trim();
            if (result.size() == maxLines - 1 && !remaining.isEmpty()) {
                while (paint.measureText(line + "…") > width && line.length() > 1) {
                    line = line.substring(0, line.length() - 1);
                }
                line += "…";
                remaining = "";
            }
            result.add(line);
        }
        if (result.isEmpty()) result.add("—");
        return result;
    }

    private static String fullText(ShareCardData data) {
        StringBuilder text = new StringBuilder();
        text.append(ShareCardData.BRAND).append('\n')
                .append(data.status).append(" • SEVERITY ").append(data.severity)
                .append(" • ").append(data.credibility).append("\n\n")
                .append(data.title).append("\n\n")
                .append(data.summary).append("\n\n");
        for (Map.Entry<String, String> fact : data.facts.entrySet()) {
            text.append(fact.getKey()).append(": ").append(fact.getValue()).append('\n');
        }
        text.append("\nCATEGORY: ").append(data.category)
                .append("\nREGION: ").append(data.region)
                .append("\nSOURCE: ").append(data.source)
                .append("\nUTC: ").append(utc(data.timestampMs));
        if (data.hasLocation()) {
            text.append(String.format(Locale.US, "\nCOORDINATES: %.5f, %.5f",
                    data.latitude, data.longitude));
        }
        if (!data.sourceUrl.isEmpty()) text.append("\nORIGINAL SOURCE: ").append(data.sourceUrl);
        text.append("\n\n").append(data.disclaimer);
        return text.toString();
    }

    private static String utc(long timestampMs) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(timestampMs));
    }

    private static String clip(String value, int maximum) {
        String clean = value == null ? "" : value.trim().replaceAll("\\s+", " ");
        return clean.length() <= maximum ? clean
                : clean.substring(0, Math.max(1, maximum - 1)) + "…";
    }

    private static void prune(File directory) {
        File[] files = directory.listFiles();
        if (files == null || files.length <= 20) return;
        java.util.Arrays.sort(files, (first, second) ->
                Long.compare(first.lastModified(), second.lastModified()));
        for (int index = 0; index < files.length - 20; index++) {
            // Cache cleanup is best effort. A receiver with an open descriptor is unaffected.
            files[index].delete();
        }
    }
}
