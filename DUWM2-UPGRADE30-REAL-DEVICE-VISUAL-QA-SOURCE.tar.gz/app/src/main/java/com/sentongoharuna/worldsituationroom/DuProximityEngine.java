package com.sentongoharuna.worldsituationroom;
import java.util.*;
public final class DuProximityEngine{
 public static final class Contact{public final Signal signal;public final double distanceKm,bearingDeg;Contact(Signal s,double d,double b){signal=s;distanceKm=d;bearingDeg=b;}}
 public static List<Contact> nearby(Signal anchor,List<Signal> candidates,double radiusKm,int limit){
  List<Contact> out=new ArrayList<>();if(anchor==null||!anchor.hasLocation()||candidates==null)return out;
  for(Signal s:candidates){if(s==null||s.id.equals(anchor.id)||!s.hasLocation())continue;double d=distance(anchor.latitude,anchor.longitude,s.latitude,s.longitude);if(d<=radiusKm)out.add(new Contact(s,d,bearing(anchor.latitude,anchor.longitude,s.latitude,s.longitude)));}
  Collections.sort(out,(a,b)->Double.compare(a.distanceKm,b.distanceKm));return out.subList(0,Math.min(Math.max(0,limit),out.size()));
 }
 public static double distance(double a,double o,double b,double p){double r=6371.0088,d1=Math.toRadians(b-a),d2=Math.toRadians(p-o),x=Math.sin(d1/2)*Math.sin(d1/2)+Math.cos(Math.toRadians(a))*Math.cos(Math.toRadians(b))*Math.sin(d2/2)*Math.sin(d2/2);return 2*r*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));}
 public static double bearing(double a,double o,double b,double p){double y=Math.sin(Math.toRadians(p-o))*Math.cos(Math.toRadians(b)),x=Math.cos(Math.toRadians(a))*Math.sin(Math.toRadians(b))-Math.sin(Math.toRadians(a))*Math.cos(Math.toRadians(b))*Math.cos(Math.toRadians(p-o));return(Math.toDegrees(Math.atan2(y,x))+360)%360;}
 public static String compass(double d){String[]x={"N","NE","E","SE","S","SW","W","NW"};return x[(int)Math.round(d/45d)%8];}
}