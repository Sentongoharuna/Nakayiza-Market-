package com.sentongoharuna.worldsituationroom;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaMetadataRetriever;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Durable local report/outbox store. Remote failure never destroys a reporter's captured video. */
public final class MonitorStore {
    private static final String STORE = "du_local_monitor_reports_v1";
    private static final String REPORTS = "reports";
    private static final String COMMENTS = "comments";
    private static final long MAX_VIDEO_BYTES = 768L * 1024L * 1024L;
    private static final int MAX_REPORTS = 120;
    private static final int MAX_COMMENTS_PER_REPORT = 100;

    private final Context app;
    private final SharedPreferences preferences;
    private final File mediaDirectory;

    public MonitorStore(Context context) {
        app = context.getApplicationContext();
        preferences = app.getSharedPreferences(STORE, Context.MODE_PRIVATE);
        File primary = new File(app.getFilesDir(), "monitor-media");
        if (primary.isDirectory() || primary.mkdirs()) {
            mediaDirectory = primary;
            return;
        }
        File fallback = new File(app.getNoBackupFilesDir(), "monitor-media-recovery");
        if (!fallback.isDirectory() && !fallback.mkdirs()) {
            throw new IllegalStateException("Unable to create local monitor media directory");
        }
        mediaDirectory = fallback;
    }

    public synchronized List<MonitorReport> reports() {
        List<MonitorReport> reports = MonitorReport.listFromJson(
                SafePreferences.string(preferences, REPORTS, "[]"));
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (int index = reports.size() - 1; index >= 0; index--) {
            MonitorReport report = reports.get(index);
            if (report.isExpired(now)) {
                reports.remove(index);
                changed = true;
            }
        }
        sort(reports);
        if (changed) saveReports(reports);
        return reports;
    }

    public synchronized List<MonitorReport> mergeRemote(List<MonitorReport> remote) {
        Map<String, MonitorReport> merged = new LinkedHashMap<>();
        for (MonitorReport local : reports()) merged.put(local.id, local);
        if (remote != null) {
            for (MonitorReport incoming : remote) {
                if (incoming == null || incoming.id == null || incoming.id.trim().isEmpty()) continue;
                MonitorReport existing = merged.get(incoming.id);
                if (existing != null && existing.hasLocalVideo()) {
                    incoming.localFileName = existing.localFileName;
                }
                merged.put(incoming.id, incoming);
            }
        }
        List<MonitorReport> result = new ArrayList<>(merged.values());
        sort(result);
        if (result.size() > MAX_REPORTS) result = new ArrayList<>(result.subList(0, MAX_REPORTS));
        saveReports(result);
        return result;
    }

    public synchronized void upsert(MonitorReport report) {
        List<MonitorReport> values = reports();
        for (int index = values.size() - 1; index >= 0; index--) {
            if (values.get(index).id.equals(report.id)) values.remove(index);
        }
        values.add(report);
        sort(values);
        if (values.size() > MAX_REPORTS) values = new ArrayList<>(values.subList(0, MAX_REPORTS));
        saveReports(values);
    }

    public synchronized MonitorReport find(String reportId) {
        for (MonitorReport report : reports()) {
            if (report.id.equals(reportId)) return report;
        }
        return null;
    }

    public synchronized boolean toggleLike(String reportId) {
        MonitorReport report = find(reportId);
        if (report == null) return false;
        report.liked = !report.liked;
        report.likes = Math.max(0, report.likes + (report.liked ? 1 : -1));
        upsert(report);
        return report.liked;
    }

    public synchronized void deleteOwnReport(String reportId, String ownProfileId) {
        List<MonitorReport> values = reports();
        for (int index = values.size() - 1; index >= 0; index--) {
            MonitorReport report = values.get(index);
            if (!report.id.equals(reportId) || !report.profileId.equals(ownProfileId)) continue;
            values.remove(index);
            if (report.hasLocalVideo()) {
                File media = fileForName(report.localFileName);
                if (media != null) media.delete();
            }
        }
        saveReports(values);
    }

    public synchronized void removeRecordKeepMedia(String reportId) {
        List<MonitorReport> values = reports();
        for (int index = values.size() - 1; index >= 0; index--) {
            if (values.get(index).id.equals(reportId)) values.remove(index);
        }
        saveReports(values);
    }

    public synchronized List<MonitorReport.Comment> comments(String reportId) {
        List<MonitorReport.Comment> result = new ArrayList<>();
        try {
            JSONObject root = new JSONObject(SafePreferences.string(
                    preferences, COMMENTS, "{}"));
            JSONArray values = root.optJSONArray(reportId);
            if (values == null) return result;
            int start = Math.max(0, values.length() - MAX_COMMENTS_PER_REPORT);
            for (int index = start; index < values.length(); index++) {
                JSONObject value = values.optJSONObject(index);
                if (value != null) result.add(MonitorReport.Comment.fromJson(value));
            }
        } catch (Exception ignored) {
            // Corrupt comment cache is isolated from video reports.
        }
        return result;
    }

    public synchronized void mergeComments(
            String reportId,
            List<MonitorReport.Comment> incoming) {
        Map<String, MonitorReport.Comment> merged = new LinkedHashMap<>();
        for (MonitorReport.Comment comment : comments(reportId)) merged.put(comment.id, comment);
        if (incoming != null) {
            for (MonitorReport.Comment comment : incoming) {
                if (comment != null && !comment.body.isEmpty()) merged.put(comment.id, comment);
            }
        }
        saveComments(reportId, new ArrayList<>(merged.values()));
    }

    public synchronized void addComment(String reportId, MonitorReport.Comment comment) {
        List<MonitorReport.Comment> values = comments(reportId);
        values.add(comment);
        saveComments(reportId, values);
        MonitorReport report = find(reportId);
        if (report != null) {
            report.commentCount = Math.max(report.commentCount + 1, values.size());
            upsert(report);
        }
    }

    public String importVideo(ContentResolver resolver, Uri source) throws IOException {
        if (resolver == null || source == null) throw new IOException("No video was selected");
        String name = "report-" + UUID.randomUUID().toString().replace("-", "") + ".mp4";
        File partial = new File(mediaDirectory, name + ".part");
        File target = new File(mediaDirectory, name);
        long copied = 0L;
        try (InputStream raw = resolver.openInputStream(source)) {
            if (raw == null) throw new IOException("The selected video could not be opened");
            try (BufferedInputStream input = new BufferedInputStream(raw, 64 * 1024);
                 BufferedOutputStream output = new BufferedOutputStream(
                         new FileOutputStream(partial), 64 * 1024)) {
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    copied += read;
                    if (copied > MAX_VIDEO_BYTES) {
                        throw new IOException("Video is larger than the 768 MB report limit");
                    }
                    output.write(buffer, 0, read);
                }
            }
            if (copied < 1_024L) throw new IOException("The selected video is empty");
            if (!partial.renameTo(target)) throw new IOException("Unable to secure the local video copy");
            return name;
        } finally {
            if (partial.exists()) partial.delete();
        }
    }

    public String createCaptureTarget() throws IOException {
        String name = "capture-" + UUID.randomUUID().toString().replace("-", "") + ".mp4";
        File target = new File(mediaDirectory, name);
        if (!target.createNewFile()) throw new IOException("Unable to reserve camera output");
        return name;
    }

    public void discardMedia(String fileName) {
        File file = fileForName(fileName);
        if (file != null) file.delete();
    }

    public long durationMs(String fileName) {
        File file = fileForName(fileName);
        if (file == null || !file.isFile()) return 0L;
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(file.getAbsolutePath());
            String value = retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION);
            return value == null ? 0L : Math.max(0L, Long.parseLong(value));
        } catch (Exception ignored) {
            return 0L;
        } finally {
            try {
                retriever.release();
            } catch (Exception ignored) {
                // Older devices may already have released the native retriever.
            }
        }
    }

    public Uri mediaUri(String fileName) {
        File file = fileForName(fileName);
        if (file == null || !file.isFile()) return null;
        return Uri.parse("content://" + app.getPackageName() + ".monitor-media/" + file.getName());
    }

    public File mediaFile(String fileName) {
        File file = fileForName(fileName);
        return file != null && file.isFile() ? file : null;
    }

    private File fileForName(String fileName) {
        String clean = fileName == null ? "" : fileName.trim();
        if (!clean.matches("[A-Za-z0-9._-]+")) return null;
        try {
            File file = new File(mediaDirectory, clean).getCanonicalFile();
            if (!file.getParentFile().equals(mediaDirectory.getCanonicalFile())) return null;
            return file;
        } catch (IOException ignored) {
            return null;
        }
    }

    private void saveReports(List<MonitorReport> reports) {
        JSONArray values = new JSONArray();
        int limit = Math.min(reports.size(), MAX_REPORTS);
        for (int index = 0; index < limit; index++) {
            try {
                values.put(reports.get(index).toJson());
            } catch (Exception ignored) {
                // One malformed cached report must not block all other local reports.
            }
        }
        preferences.edit().putString(REPORTS, values.toString()).apply();
    }

    private void saveComments(String reportId, List<MonitorReport.Comment> comments) {
        try {
            JSONObject root = new JSONObject(SafePreferences.string(
                    preferences, COMMENTS, "{}"));
            JSONArray values = new JSONArray();
            int start = Math.max(0, comments.size() - MAX_COMMENTS_PER_REPORT);
            for (int index = start; index < comments.size(); index++) {
                values.put(comments.get(index).toJson());
            }
            root.put(reportId, values);
            preferences.edit().putString(COMMENTS, root.toString()).apply();
        } catch (Exception ignored) {
            // Comments are secondary; report playback must remain available.
        }
    }

    private static void sort(List<MonitorReport> reports) {
        Collections.sort(reports, new Comparator<MonitorReport>() {
            @Override public int compare(MonitorReport first, MonitorReport second) {
                if (first.live != second.live) return first.live ? -1 : 1;
                return Long.compare(second.createdAtMs, first.createdAtMs);
            }
        });
    }
}
