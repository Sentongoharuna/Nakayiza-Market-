package com.sentongoharuna.worldsituationroom;
import android.app.*;import android.view.*;import android.widget.*;
public final class DuGeoPreview{
 public static View make(Activity a,String system,String id){LinearLayout c=Du2Ui.panel(a,"GEOGRAPHIC CONTEXT","● SOURCE COORDINATES","Native mini-map uses provider coordinates and observed fixes; no invented position.");
  DuLiveRepository r=new DuLiveRepository(a);Signal s=r.find(system,id);DuMiniMapView map=new DuMiniMapView(a,id);if(s!=null&&s.hasLocation())map.setPosition(s.latitude,s.longitude);map.setOnClickListener(v->{DuUiMotion.press(v);a.startActivity(DuFlow.globe(a,system,id));});c.addView(map,new LinearLayout.LayoutParams(-1,Du2Ui.dp(a,190)));
  LinearLayout row=new LinearLayout(a);Button globe=Du2Ui.button(a,"OPEN FOCUSED GLOBE");globe.setOnClickListener(v->a.startActivity(DuFlow.globe(a,system,id)));Button track=Du2Ui.button(a,"TRACK");track.setOnClickListener(v->{Signal x=r.find(system,id);if(x!=null)a.startActivity(DuSignalIntent.track(a,x));});row.addView(globe,new LinearLayout.LayoutParams(0,50,1));row.addView(track,new LinearLayout.LayoutParams(0,50,1));c.addView(row);return c;
 }
}