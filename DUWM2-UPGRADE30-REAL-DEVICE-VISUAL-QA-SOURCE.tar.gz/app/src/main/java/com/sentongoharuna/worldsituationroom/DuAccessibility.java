package com.sentongoharuna.worldsituationroom;
import android.content.*;import android.provider.Settings;import android.view.*;import android.widget.*;
public final class DuAccessibility{
 static final String P="duwm_accessibility_v1";
 public static boolean reducedMotion(Context c){boolean manual=c.getSharedPreferences(P,0).getBoolean("reduced_motion",false);float scale=1f;try{scale=Settings.Global.getFloat(c.getContentResolver(),Settings.Global.ANIMATOR_DURATION_SCALE,1f);}catch(Exception ignored){}return manual||scale==0f;}
 public static void reducedMotion(Context c,boolean on){c.getSharedPreferences(P,0).edit().putBoolean("reduced_motion",on).apply();}
 public static int motionMs(Context c,int normal){return reducedMotion(c)?0:normal;}
 public static <T extends View>T target(T v,String description){v.setMinimumWidth(dp(v.getContext(),48));v.setMinimumHeight(dp(v.getContext(),48));if(description!=null&&!description.isEmpty())v.setContentDescription(description);v.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);return v;}
 public static void heading(TextView v){if(android.os.Build.VERSION.SDK_INT>=28)v.setAccessibilityHeading(true);}
 static int dp(Context c,int n){return(int)(n*c.getResources().getDisplayMetrics().density+.5f);}
}