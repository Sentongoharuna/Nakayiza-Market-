package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuRelatedEngine{
 public static final class Relation{public final Signal signal;public final double score;public final String why;Relation(Signal s,double x,String w){signal=s;score=x;why=w;}}
 final Context c;final DuLiveRepository repo;
 public DuRelatedEngine(Context c){this.c=c;repo=new DuLiveRepository(c);}
 public List<Relation> related(Signal anchor,int limit){List<Relation> out=new ArrayList<>();if(anchor==null)return out;for(String sys:new String[]{"NEWS","EVENTS","WX","AIRWX","AIR","SEA","ORBIT","INFRA","CAM"})for(Signal s:repo.signals(sys)){if(s==null||s.id.equals(anchor.id))continue;Relation r=score(anchor,s);if(r.score>=.28)out.add(r);}Collections.sort(out,(a,b)->Double.compare(b.score,a.score));return out.subList(0,Math.min(limit,out.size()));}
 Relation score(Signal a,Signal b){double score=0;List<String> why=new ArrayList<>();long dt=Math.abs(a.timestampMs-b.timestampMs);if(dt<=60*60*1000L){score+=.24;why.add("≤1h");}else if(dt<=6L*60*60*1000L){score+=.16;why.add("≤6h");}else if(dt<=24L*60*60*1000L){score+=.08;why.add("≤24h");}
  if(a.hasLocation()&&b.hasLocation()){double d=DuProximityEngine.distance(a.latitude,a.longitude,b.latitude,b.longitude);if(d<=25){score+=.38;why.add(String.format(Locale.US,"%.0f km",d));}else if(d<=100){score+=.28;why.add(String.format(Locale.US,"%.0f km",d));}else if(d<=300){score+=.16;why.add(String.format(Locale.US,"%.0f km",d));}}
  if(!a.region.isEmpty()&&a.region.equalsIgnoreCase(b.region)&&!"GLOBAL".equalsIgnoreCase(a.region)){score+=.12;why.add("same region");}
  if(!a.eventType.isEmpty()&&a.eventType.equalsIgnoreCase(b.eventType)&&!"OTHER".equalsIgnoreCase(a.eventType)){score+=.14;why.add("same event type");}
  double words=wordScore(a.title+" "+a.summary,b.title+" "+b.summary);if(words>0){score+=Math.min(.30,words*.35);why.add("entity/topic overlap");}
  if(a.layer!=b.layer){score+=.04;why.add("cross-domain");}
  return new Relation(b,Math.min(1,score),String.join(" · ",why));}
 static double wordScore(String a,String b){Set<String>x=tokens(a),y=tokens(b);if(x.isEmpty()||y.isEmpty())return 0;int n=0;for(String q:x)if(y.contains(q))n++;return n/(double)Math.min(x.size(),y.size());}
 static Set<String> tokens(String s){LinkedHashSet<String>o=new LinkedHashSet<>();for(String q:(s==null?"":s.toLowerCase(Locale.ROOT)).replaceAll("[^a-z0-9 ]"," ").split("\\s+"))if(q.length()>4&&!Arrays.asList("about","after","before","their","there","which","would","could","source","report","update").contains(q))o.add(q);return o;}
}