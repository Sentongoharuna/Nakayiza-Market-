package com.sentongoharuna.worldsituationroom;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;

import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.net.ssl.HttpsURLConnection;

/**
 * Native-only public media surface. It never evaluates HTML or JavaScript and never embeds
 * a website: direct TV streams use Android's media stack and camera frames use ImageView.
 */
public final class NativeMediaActivity extends Activity {
    public static final String EXTRA_KIND = "kind";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_SOURCE = "source";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_REFERRER = "referrer";
    public static final String EXTRA_USER_AGENT = "user_agent";
    public static final String KIND_VIDEO = "VIDEO";
    public static final String KIND_IMAGE = "IMAGE";

    private static final int BG = Color.rgb(5, 8, 12);
    private static final int PANEL = Color.rgb(14, 21, 29);
    private static final int LINE = Color.rgb(39, 53, 65);
    private static final int TEXT = Color.rgb(235, 241, 244);
    private static final int MUTED = Color.rgb(139, 155, 166);
    private static final int CYAN = Color.rgb(112, 177, 201);
    private static final long MAX_IMAGE_BYTES = 12L * 1024L * 1024L;
    private static final long CAMERA_REFRESH_MS = 12_000L;

    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();
    private final Handler cameraHandler = new Handler(Looper.getMainLooper());
    private final SimpleDateFormat frameClock = new SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US);
    private TextView status;
    private ProgressBar progress;
    private VideoView videoView;
    private ImageView imageView;
    private Future<?> imageTask;
    private volatile HttpsURLConnection imageConnection;
    private int imageLoadToken;
    private String mediaUrl = "";
    private TextView cameraSignal;
    private boolean cameraPulseOn;
    private int acquiredFrames;
    private boolean imageMode;
    private final Runnable cameraRefresh = new Runnable() {
        @Override public void run() {
            if (imageMode && !isFinishing() && !isDestroyed()) loadImage();
        }
    };
    private final Runnable cameraPulse = new Runnable() {
        @Override public void run() {
            if (!imageMode || cameraSignal == null || isFinishing() || isDestroyed()) return;
            cameraPulseOn = !cameraPulseOn;
            cameraSignal.setAlpha(cameraPulseOn ? 1f : 0.48f);
            cameraHandler.postDelayed(this, cameraPulseOn ? 420L : 720L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        frameClock.setTimeZone(TimeZone.getTimeZone("UTC"));

        String kind = clean(getIntent().getStringExtra(EXTRA_KIND));
        String title = clean(getIntent().getStringExtra(EXTRA_TITLE));
        String source = clean(getIntent().getStringExtra(EXTRA_SOURCE));
        mediaUrl = clean(getIntent().getStringExtra(EXTRA_URL));
        if (!safePublicHttpsUrl(mediaUrl)
                || (!KIND_VIDEO.equals(kind) && !KIND_IMAGE.equals(kind))) {
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.setBackgroundColor(BG);

        LinearLayout command = new LinearLayout(this);
        command.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading = label(title.isEmpty() ? "PUBLIC MEDIA" : title, TEXT, 16, true);
        command.addView(heading, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button close = button("CLOSE");
        close.setOnClickListener(view -> finish());
        command.addView(close, new LinearLayout.LayoutParams(dp(76), dp(46)));
        root.addView(command);

        TextView sourceLabel = label("SOURCE  " + (source.isEmpty() ? "PUBLIC PROVIDER" : source),
                MUTED, 10, false);
        sourceLabel.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        root.addView(sourceLabel, marginParams(0, 6, 0, 8));

        FrameLayout stage = new FrameLayout(this);
        stage.setBackground(panelBackground(PANEL, LINE, 18));
        root.addView(stage, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                dp(46), dp(46), Gravity.CENTER);
        stage.addView(progress, progressParams);

        status = label(KIND_VIDEO.equals(kind)
                        ? "CONNECTING DIRECT PUBLIC STREAM…"
                        : "LOADING LATEST PUBLIC CAMERA FRAME…",
                CYAN, 10, true);
        status.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        status.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52), Gravity.BOTTOM);
        statusParams.setMargins(dp(10), 0, dp(10), dp(10));
        stage.addView(status, statusParams);

        if (KIND_VIDEO.equals(kind)) {
            buildVideo(stage);
        } else {
            buildImage(stage);
        }

        TextView notice = label(
                KIND_VIDEO.equals(kind)
                        ? "DIRECT NATIVE PLAYBACK  •  NO WEB PAGE  •  AVAILABILITY AND GEO-RESTRICTIONS MAY VARY"
                        : "DIRECT PROVIDER IMAGE  •  NO WEB PAGE  •  FRAME TIME IS CONTROLLED BY THE CAMERA PUBLISHER",
                MUTED, 9, false);
        notice.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
        notice.setGravity(Gravity.CENTER);
        root.addView(notice, marginParams(0, 10, 0, 0));

        Button share = button("SHARE INFORMATION CARD");
        share.setContentDescription("Share this public media information as a DU World Monitor card");
        share.setOnClickListener(view -> {
            Map<String, String> facts = new LinkedHashMap<>();
            facts.put("MEDIA TYPE", KIND_IMAGE.equals(kind) ? "PUBLIC CAMERA" : "PUBLIC TV");
            facts.put("PLAYBACK", "Direct native media; no embedded web page");
            facts.put("CURRENT STATE", status == null ? "OPEN" : status.getText().toString());
            if (KIND_IMAGE.equals(kind)) {
                facts.put("FRAME REFRESH", "Automatic every 12 seconds while this page is visible");
            }
            ShareCardRenderer.share(this, new ShareCardData(
                    title.isEmpty() ? "Public media" : title,
                    KIND_IMAGE.equals(kind)
                            ? "Public camera information and current native frame availability."
                            : "Public television stream information and current native playback availability.",
                    KIND_IMAGE.equals(kind) ? "CAMERA" : "TELEVISION",
                    "PUBLIC SOURCE — AVAILABILITY VARIES",
                    KIND_IMAGE.equals(kind) ? "CAMERAS" : "TV",
                    "GLOBAL", 1,
                    source.isEmpty() ? "Public provider" : source,
                    mediaUrl, System.currentTimeMillis(), Double.NaN, Double.NaN,
                    facts, CYAN,
                    "Publisher uptime, geoblocking and frame timing can change. Verify information with the named source."));
        });
        root.addView(share, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
        setContentView(root);
    }

    private void buildVideo(FrameLayout stage) {
        videoView = new VideoView(this);
        stage.addView(videoView, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        MediaController controls = new MediaController(this);
        controls.setAnchorView(videoView);
        videoView.setMediaController(controls);

        Map<String, String> headers = new HashMap<>();
        String referrer = clean(getIntent().getStringExtra(EXTRA_REFERRER));
        String userAgent = clean(getIntent().getStringExtra(EXTRA_USER_AGENT));
        if (safeHeader(referrer)) headers.put("Referer", referrer);
        headers.put("User-Agent", safeHeader(userAgent) ? userAgent : AppConfig.USER_AGENT);

        videoView.setOnPreparedListener(player -> {
            progress.setVisibility(View.GONE);
            status.setText("PLAYING / PUBLIC TV STREAM");
            status.setTextColor(Color.rgb(75, 166, 124));
            player.setOnInfoListener((ignored, what, extra) -> {
                if (what == android.media.MediaPlayer.MEDIA_INFO_BUFFERING_START) {
                    status.setText("BUFFERING / PUBLIC TV STREAM");
                    progress.setVisibility(View.VISIBLE);
                } else if (what == android.media.MediaPlayer.MEDIA_INFO_BUFFERING_END) {
                    status.setText("PLAYING / PUBLIC TV STREAM");
                    progress.setVisibility(View.GONE);
                }
                return false;
            });
            videoView.start();
        });
        videoView.setOnErrorListener((player, what, extra) -> {
            progress.setVisibility(View.GONE);
            status.setTextColor(Color.rgb(219, 73, 80));
            status.setText("STREAM UNAVAILABLE / TRY ANOTHER CHANNEL");
            return true;
        });
        videoView.setVideoURI(Uri.parse(mediaUrl), headers);
        videoView.requestFocus();
    }

    private void buildImage(FrameLayout stage) {
        imageMode = true;
        imageView = new ImageView(this);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        stage.addView(imageView, 0, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Button refresh = button("REFRESH FRAME");
        refresh.setOnClickListener(view -> loadImage());
        FrameLayout.LayoutParams refreshParams = new FrameLayout.LayoutParams(
                dp(128), dp(44), Gravity.TOP | Gravity.END);
        refreshParams.setMargins(0, dp(10), dp(10), 0);
        stage.addView(refresh, refreshParams);
        cameraSignal = label("● CAMERA / AUTO 12s", Color.rgb(219, 73, 80), 9, true);
        cameraSignal.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        FrameLayout.LayoutParams signalParams = new FrameLayout.LayoutParams(
                dp(170), dp(38), Gravity.TOP | Gravity.START);
        signalParams.setMargins(dp(10), dp(10), 0, 0);
        stage.addView(cameraSignal, signalParams);
        cameraHandler.post(cameraPulse);
        loadImage();
    }

    private void loadImage() {
        Future<?> previous = imageTask;
        if (previous != null) previous.cancel(true);
        HttpsURLConnection previousConnection = imageConnection;
        if (previousConnection != null) previousConnection.disconnect();
        final int token = ++imageLoadToken;
        progress.setVisibility(View.VISIBLE);
        status.setTextColor(CYAN);
        status.setText("LOADING LATEST PUBLIC CAMERA FRAME…");
        imageTask = imageExecutor.submit(() -> {
            try {
                byte[] bytes = downloadImage(mediaUrl);
                Bitmap bitmap = decodeBounded(bytes, 2_400);
                if (bitmap == null) throw new IOException("Unsupported camera image");
                runOnUiThread(() -> {
                    if (token != imageLoadToken || isFinishing() || isDestroyed()) {
                        bitmap.recycle();
                        return;
                    }
                    imageView.setImageBitmap(bitmap);
                    progress.setVisibility(View.GONE);
                    status.setTextColor(Color.rgb(75, 166, 124));
                    acquiredFrames++;
                    status.setText(String.format(Locale.US,
                            "● FRAME %04d ACQUIRED / %s / NEXT 12s",
                            acquiredFrames, frameClock.format(new Date())));
                    cameraHandler.removeCallbacks(cameraRefresh);
                    cameraHandler.postDelayed(cameraRefresh, CAMERA_REFRESH_MS);
                });
            } catch (Exception error) {
                if (token != imageLoadToken || Thread.currentThread().isInterrupted()) return;
                runOnUiThread(() -> {
                    if (token != imageLoadToken) return;
                    progress.setVisibility(View.GONE);
                    status.setTextColor(Color.rgb(219, 73, 80));
                    status.setText("CAMERA FRAME UNAVAILABLE / REFRESH THE CAMERA INDEX");
                    cameraHandler.removeCallbacks(cameraRefresh);
                    cameraHandler.postDelayed(cameraRefresh, 24_000L);
                });
            }
        });
    }

    private byte[] downloadImage(String startUrl) throws IOException {
        URL target = new URL(startUrl);
        for (int redirect = 0; redirect <= 4; redirect++) {
            if (!safePublicHttpsUrl(target.toString())) {
                throw new IOException("Unsafe camera address refused");
            }
            HttpsURLConnection connection = (HttpsURLConnection) target.openConnection();
            imageConnection = connection;
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(8_000);
            connection.setReadTimeout(14_000);
            connection.setRequestProperty("User-Agent", AppConfig.USER_AGENT);
            connection.setRequestProperty("Accept", "image/*");
            connection.setRequestProperty("Cache-Control", "no-cache");
            try {
                int code = connection.getResponseCode();
                if (code >= 300 && code < 400) {
                    String location = connection.getHeaderField("Location");
                    if (location == null || location.trim().isEmpty()) {
                        throw new IOException("Camera redirect has no target");
                    }
                    target = new URL(target, location);
                    continue;
                }
                String contentType = connection.getContentType();
                if (code < 200 || code >= 300 || contentType == null
                        || !contentType.toLowerCase(Locale.ROOT).startsWith("image/")) {
                    throw new IOException("Camera did not return an image");
                }
                long declared = connection.getContentLength();
                if (declared > MAX_IMAGE_BYTES) throw new IOException("Camera frame too large");
                try (InputStream input = connection.getInputStream();
                     ByteArrayOutputStream output = new ByteArrayOutputStream(
                             declared > 0L && declared < Integer.MAX_VALUE
                                     ? (int) declared : 128 * 1024)) {
                    byte[] buffer = new byte[16 * 1024];
                    int total = 0;
                    int read;
                    while ((read = input.read(buffer)) != -1) {
                        total += read;
                        if (total > MAX_IMAGE_BYTES) {
                            throw new IOException("Camera frame too large");
                        }
                        output.write(buffer, 0, read);
                    }
                    return output.toByteArray();
                }
            } finally {
                connection.disconnect();
                if (imageConnection == connection) imageConnection = null;
            }
        }
        throw new IOException("Too many camera redirects");
    }

    private static Bitmap decodeBounded(byte[] bytes, int maximumDimension) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > maximumDimension) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = Math.max(1, sample);
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, options);
    }

    private static boolean safeHeader(String value) {
        return value != null && !value.trim().isEmpty()
                && value.length() <= 320
                && value.indexOf('\r') < 0 && value.indexOf('\n') < 0;
    }

    private static boolean safePublicHttpsUrl(String value) {
        return PublicMediaPolicy.isSafePublicHttpsUrl(value);
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextColor(TEXT);
        button.setTextSize(10);
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        button.setAllCaps(false);
        button.setBackground(panelBackground(PANEL, LINE, 12));
        return button;
    }

    private TextView label(String value, int color, int sizeSp, boolean bold) {
        TextView label = new TextView(this);
        label.setText(value);
        label.setTextColor(color);
        label.setTextSize(sizeSp);
        label.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif",
                Typeface.NORMAL));
        return label;
    }

    private GradientDrawable panelBackground(int fill, int stroke, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setStroke(dp(1), stroke);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private LinearLayout.LayoutParams marginParams(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static String clean(String value) {
        return value == null ? "" : value.trim().replaceAll("[\\r\\n]+", " ");
    }

    @Override
    protected void onDestroy() {
        cameraHandler.removeCallbacksAndMessages(null);
        imageLoadToken++;
        Future<?> current = imageTask;
        if (current != null) current.cancel(true);
        HttpsURLConnection connection = imageConnection;
        if (connection != null) connection.disconnect();
        imageExecutor.shutdownNow();
        if (videoView != null) videoView.stopPlayback();
        super.onDestroy();
    }
}
