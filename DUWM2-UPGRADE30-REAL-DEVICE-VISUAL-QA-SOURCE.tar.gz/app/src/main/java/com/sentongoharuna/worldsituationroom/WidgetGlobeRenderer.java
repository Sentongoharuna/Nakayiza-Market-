package com.sentongoharuna.worldsituationroom;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.List;

/** Lightweight orthographic signal snapshot for the large home-screen command widget. */
public final class WidgetGlobeRenderer {
    private WidgetGlobeRenderer() { }

    public static Bitmap render(List<Signal> signals, double centerLatitude,
                                double centerLongitude, int width, int height) {
        // RemoteViews crosses Binder; stay comfortably below its transaction ceiling even on
        // tablet launchers that report very large widget bounds.
        int safeWidth = Math.max(320, Math.min(600, width));
        int safeHeight = Math.max(150, Math.min(300, height));
        Bitmap bitmap = Bitmap.createBitmap(safeWidth, safeHeight, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.rgb(4, 8, 12));
        float cx = safeWidth / 2f;
        float cy = safeHeight / 2f;
        float radius = Math.min(safeWidth * 0.45f, safeHeight * 0.43f);

        Paint atmosphere = new Paint(Paint.ANTI_ALIAS_FLAG);
        atmosphere.setShader(new RadialGradient(cx - radius * 0.25f, cy - radius * 0.28f,
                radius * 1.2f,
                new int[]{Color.rgb(24, 67, 82), Color.rgb(8, 27, 39), Color.rgb(2, 8, 13)},
                new float[]{0f, 0.72f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, radius, atmosphere);

        Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(Math.max(2f, radius / 110f));
        rim.setColor(Color.rgb(112, 177, 201));
        rim.setAlpha(220);
        canvas.drawCircle(cx, cy, radius, rim);

        Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(Math.max(1f, radius / 250f));
        grid.setColor(Color.rgb(74, 112, 126));
        grid.setAlpha(90);
        for (int latitude = -60; latitude <= 60; latitude += 30) {
            drawGeoLine(canvas, grid, true, latitude, centerLatitude, centerLongitude,
                    cx, cy, radius);
        }
        for (int longitude = -150; longitude <= 180; longitude += 30) {
            drawGeoLine(canvas, grid, false, longitude, centerLatitude, centerLongitude,
                    cx, cy, radius);
        }

        Paint point = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        ring.setStyle(Paint.Style.STROKE);
        int shown = 0;
        if (signals != null) {
            for (Signal signal : signals) {
                if (!signal.hasLocation() || shown >= 230) continue;
                float[] projected = project(signal.latitude, signal.longitude,
                        centerLatitude, centerLongitude, cx, cy, radius);
                if (projected == null) continue;
                int color = layerColor(signal);
                float size = signal.severity >= 4 ? 5.5f : 3.2f;
                ring.setColor(color);
                ring.setAlpha(signal.severity >= 4 ? 145 : 70);
                ring.setStrokeWidth(1.5f);
                canvas.drawCircle(projected[0], projected[1], size * 2.1f, ring);
                point.setColor(color);
                point.setAlpha(235);
                canvas.drawCircle(projected[0], projected[1], size, point);
                shown++;
            }
        }

        Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);
        cross.setColor(Color.rgb(235, 241, 244));
        cross.setAlpha(155);
        cross.setStrokeWidth(1.2f);
        canvas.drawLine(cx - 6f, cy, cx + 6f, cy, cross);
        canvas.drawLine(cx, cy - 6f, cx, cy + 6f, cross);

        Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
        label.setColor(Color.rgb(139, 155, 166));
        label.setTextSize(Math.max(10f, safeWidth / 46f));
        label.setTypeface(android.graphics.Typeface.MONOSPACE);
        canvas.drawText("ROTATING OBSERVED SIGNAL INDEX • COVERAGE VARIES", 10f,
                safeHeight - 9f, label);
        return bitmap;
    }

    private static void drawGeoLine(Canvas canvas, Paint paint, boolean latitudeLine,
                                    int fixed, double centerLatitude, double centerLongitude,
                                    float cx, float cy, float radius) {
        Path path = new Path();
        boolean drawing = false;
        for (int step = -180; step <= 180; step += 3) {
            double latitude = latitudeLine ? fixed : step / 2d;
            double longitude = latitudeLine ? step : fixed;
            float[] point = project(latitude, longitude, centerLatitude, centerLongitude,
                    cx, cy, radius);
            if (point == null) {
                drawing = false;
                continue;
            }
            if (!drawing) path.moveTo(point[0], point[1]);
            else path.lineTo(point[0], point[1]);
            drawing = true;
        }
        canvas.drawPath(path, paint);
    }

    private static float[] project(double latitude, double longitude,
                                   double centerLatitude, double centerLongitude,
                                   float cx, float cy, float radius) {
        double phi = Math.toRadians(latitude);
        double lambda = Math.toRadians(longitude - centerLongitude);
        double phi0 = Math.toRadians(centerLatitude);
        double visibility = Math.sin(phi0) * Math.sin(phi)
                + Math.cos(phi0) * Math.cos(phi) * Math.cos(lambda);
        if (visibility < 0d) return null;
        double x = Math.cos(phi) * Math.sin(lambda);
        double y = Math.cos(phi0) * Math.sin(phi)
                - Math.sin(phi0) * Math.cos(phi) * Math.cos(lambda);
        return new float[]{cx + (float) x * radius, cy - (float) y * radius};
    }

    private static int layerColor(Signal signal) {
        switch (signal.layer) {
            case FLIGHTS: return Color.rgb(112, 177, 201);
            case SHIPS: return Color.rgb(75, 166, 124);
            case SATELLITES: return Color.rgb(174, 139, 224);
            case NEWS: return signal.severity >= 4
                    ? Color.rgb(219, 73, 80) : Color.rgb(199, 151, 68);
            case NATURAL:
            case AIRSPACE:
            case SPACE_WEATHER: return signal.severity >= 4
                    ? Color.rgb(239, 80, 86) : Color.rgb(222, 164, 70);
            default: return Color.rgb(139, 155, 166);
        }
    }
}
