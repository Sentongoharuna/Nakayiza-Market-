package com.sentongoharuna.worldsituationroom;
import android.content.*;import java.util.*;
public final class DuRenderBudget{
 public static <T> List<T> first(Context c,List<T> src,int normal){if(src==null)return Collections.emptyList();int n=Math.min(src.size(),DuPerformancePolicy.lowMemory(c)?Math.max(20,normal/2):normal);return src.subList(0,n);}
}