# du-world moniter uses ordinary Java models and org.json; no keep rules are required.
