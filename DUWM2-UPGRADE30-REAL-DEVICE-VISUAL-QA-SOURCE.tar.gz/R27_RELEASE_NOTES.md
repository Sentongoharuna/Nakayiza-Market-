# du-world moniter R27 — Live Motion Widgets

R27 keeps the standalone native Android data and credibility pipeline from R26 and repairs the
home-screen experience so each widget remains visibly active between provider acquisitions.

## Visible motion

- Every runtime widget has an independently timed source-state pulse, so all lights do not blink
  together.
- Every runtime widget has a seconds clock that continues to move without a network request.
- Compact widgets rotate through genuine priority, event and ready-source figures.
- Bar widgets rotate through the newest source-attributed headline, provider state and health.
- Panel widgets rotate through aircraft, vessel, event, weather or media detail lines.
- The Command Centre rotates three real count surfaces: movement/events, source health, and
  weather/media coverage.
- The Command Centre globe uses eight launcher-safe motion phases over the real plotted snapshot.
  Each genuine widget redraw also advances the viewing longitude without changing record
  coordinates.

## Data integrity

- No number is randomly generated or presented as new data.
- Counts change only after provider acquisition or restored cache updates.
- `UNVERIFIED`, `REPORTED` and `CONFIRMED` credibility states remain visible.
- Sources, record age, cache age and coverage limits remain visible.
- Continuous presentation motion does not trigger continuous network traffic.

## Android/runtime contract

- Native Android `RemoteViews`; no WebView and no hosted app.
- Launcher-safe `ViewFlipper`/`TextClock` motion with a static first-frame fallback.
- Eight functional widgets and eight picker previews remain included.
- Minimum Android 6.0 (API 23); target API 35; compiled with API 36.
- Version code: `30`
- Version name: `27.0-2026-live-motion-widgets`
