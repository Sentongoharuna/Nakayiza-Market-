# du-world moniter R26 — Functional Widget Runtime Repair

R26 repairs the eight native Android home-screen widgets introduced in R25. The main app,
package identity, source credibility model, feed cache, and standalone native architecture are
preserved.

## Corrected faults

- Replaced unsupported plain `View` and `Space` elements in widget `RemoteViews` layouts with
  launcher-safe Android widget elements.
- Replaced background mutation of the status indicator with `setImageViewResource`, which is
  supported directly by `RemoteViews`.
- Added a compact safe-start and recovery layout. If an OEM launcher rejects a rich layout, the
  widget remains visible and opens the matching app page instead of disappearing.
- Added an immediate network-aware acquisition request when a widget is first enabled or updated.
- The configuration activity now installs a visible starting surface before it closes, then swaps
  in the real source-attributed snapshot asynchronously.

## Picker previews

All eight widgets now have two independent preview paths:

1. `previewLayout` XML for scalable Android 12–14 widget pickers.
2. A dedicated dark command-centre `previewImage` for Android 15–16 and older fallback hosts.

Every static preview is marked **PREVIEW** or **LIVE VALUES AFTER ADD** so example numbers cannot
be mistaken for acquired facts. The real placed widget continues to show provider source,
credibility and acquisition age.

## Widget suite retained

1. DU Alert Beacon 1×1
2. DU Live Counters 2×1
3. DU Local Watch 2×2
4. DU Breaking Wire 4×1
5. DU Air & Sea Tracker 4×2
6. DU Hazards & Weather 4×2
7. DU Media Watch 4×2
8. DU Command Centre 4×4

## Build identity

- Package: `com.sentongoharuna.worldsituationroom`
- Version code: `29`
- Version name: `26.0-2026-widget-runtime-repair`
- Minimum Android: API 23 / Android 6.0
- Compile SDK: 36
- Target SDK: 35
- Architecture: native Android Views, Canvas, TLS and media; no WebView or hosted application
