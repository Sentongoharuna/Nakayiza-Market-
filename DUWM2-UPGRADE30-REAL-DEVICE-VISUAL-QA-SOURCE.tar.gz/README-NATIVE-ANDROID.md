# DU World Monitor — Native Android R30

DU World Monitor is a standalone Android situation-awareness dashboard: **see the world,
hear the local witness**. It is built
with native Android Views, Canvas drawing, platform networking and platform media APIs.
The APK contains no WebView, hosted-site address, HTML bundle, JavaScript runtime or
third-party runtime library. R30 adds crash-loop recovery, safe video mode, bounded avatar memory,
an adaptive globe-and-DU icon and one professional brand system across the app, widgets and cards.

R24 retains the single live-operations truth engine shared by the globe, counters, pages, wire
desk and source indicators. It de-duplicates provider records, expires stale traffic,
separates provider-returned totals from retained display records, and exposes `ACQUIRING`,
`FRESH`, `DELAYED`, `CACHED`, `OFFLINE` and `KEY_REQUIRED` states. It never upgrades an
event's credibility merely because it is urgent. Compact normalized last-known snapshots
restore useful content after process death but are always labelled `CACHED`.

R24 adds a bounded 60-minute `4D REPLAY` made only from frames actually acquired during the
current app session, a transparent cross-layer `FUSION` desk, official worldwide SIGMET
aviation-weather warnings, and moving orbital context calculated locally from CelesTrak
public GP elements. Replay never manufactures history. Orbital markers are always labelled
`CALCULATED` and never described as live telemetry, tasking proof, collision analysis,
navigation data or evidence of intent.

The R22C Android 6.0 lint repair and stable detailed tracker remain included: viewport-pinned
base imagery, separate radar/label caches, parent-tile continuity during zoom, controlled
retries, off-screen request cancellation, universal share cards and every native
intelligence page. R24 adds a ten-source operations matrix, count-driven globe arcs,
change-only counter
animations, true observed provider-fix trails, progressive detail labels, provider-specific
exponential network backoff and one shared public-media safety policy.

## Live command globe

The home screen opens immediately on a native rotating globe with UTC and local clocks,
provider counters, independently timed per-source beacons, fresh-signal callouts and a moving
source crawl. R23 keeps the globe dominant: large layer and wire panels start closed, while
a compact scrolling mission dock provides one-tap access to globe, aircraft, ships,
weather, events, wire, categorized news, intelligence brief, country watch, local analyst,
4D replay, incident fusion, aviation warnings, calculated orbits, markets, airports,
ports, cameras, radio, television, space weather, infrastructure,
sources and public call/frequency-reference pages. Tap, drag, pinch
or double-tap to inspect the globe.
Detailed mode uses cached Esri satellite tiles with Carto place labels and a playable
12-frame RainViewer history covering the past two hours at ten-minute steps.

R21 keeps the privacy-preserving regional lens. At startup the app reads only Android's broad
timezone identifier and centers the globe on a useful world region such as East Africa,
Europe or Southeast Asia. It never requests GPS or location permission for this feature.
`REGION` opens that area in the detailed satellite tracker; `GLOBE` returns to the global
orthographic view. A searched city uses an explicit 650 km Local Mode; a searched country
uses the bounding envelope returned by Nominatim and is labelled as a country-bounds lens.

R21 paints a lightweight native command-deck shell before constructing the full globe,
then starts providers in stages. Cached data and small operational feeds arrive first;
large radio, television and webcam directories join later without blocking navigation.
On-device correlation runs away from Android's UI thread. Full provider result sets remain
searchable in their pages, while the Canvas receives a bounded, geographically distributed
render snapshot so global traffic cannot freeze taps or scrolling.

The two-line analysis ribbon rotates only through observed provider records. It may show a
transparent cross-source match, a cross-domain proximity watch, or regional signal density,
but it always labels correlation/proximity as `NOT CONFIRMATION` and density as
`NOT A FORECAST`. No decorative number is presented as live intelligence.

Aircraft and vessels move only when providers supply a source position, course and speed.
Between updates, the app may show a short, visibly linked estimate: no more than 60 seconds
for aircraft or 120 seconds for vessels. The hollow source-fix marker, connector and age
readout remain visible so estimated motion is never represented as a new provider fix. In
detailed mode, `OBSERVED FIX TRAIL` contains only successive provider positions and never
dead-reckoned points.

Search resolves cities and countries through OpenStreetMap Nominatim. Selecting a map
object opens a native detail view with its source, source timestamp to the second, fix age,
coordinates, movement data and provider facts.

## Native pages and direct media

`INDEX` and the mission dock open separate searchable native pages for:

- aircraft;
- ships and smaller boats;
- weather timeline, natural events, categorized news and GDELT GKG theme signals;
- official Aviation Weather Center SIGMET records and calculated CelesTrak orbital objects;
- a 4D acquired-frame replay control and incident-fusion page;
- country watch and transparent on-device movement analysis;
- FX/crypto reference markets and visible commodity-provider status;
- airports, runway summaries, ports and maritime corridors;
- NOAA space weather;
- strategic infrastructure references;
- public radio and call/frequency references;
- public television; and
- public webcams.

Radio Browser HTTPS audio plays in Android `MediaPlayer`. Filtered IPTV-org HTTPS streams
play in a native `VideoView`. Windy direct image feeds open in a native `ImageView` and
refresh every 12 seconds while visible, with an acquired-frame counter and UTC time.
Cleartext, metadata-less, closed, NSFW and provider-blocklisted television entries are
excluded. The app does not evaluate camera pages or intercept private, encrypted or
restricted communications. If no verified direct HTTPS stream exists, a frequency is
shown only as a labelled public reference. The CALLS page also joins the public-domain
OurAirports aviation-frequency directory. A lawful direct public-safety HTTPS audio stream
may be entered in Settings and played natively; the app never scrapes, decrypts or bypasses
restricted communications.

## R21 operational analysis

The `RISK` page scores 34 visible country lenses from recent mapped event severity, age,
credibility and publisher diversity. It is explicitly labelled observed signal pressure,
not a forecast or official risk rating. The `ANALYST` page keeps bounded recent aircraft and
vessel tracks and can surface emergency squawks, rapid descent, holding-like turn patterns,
prolonged low-speed vessel observations and abrupt course changes. Every watch links to its
source record and uses `OBSERVED / NOT CONFIRMED` language. A special-use callsign pattern is
never promoted to a military identity.

The `SOURCES` page makes every provider state and limitation visible, including optional
keys, provider-returned counts, licensed-wire requirements, unavailable commodity quotes,
and the fact that OpenSky public state vectors do not reliably establish military ownership
or mission. Reuters, AP and AFP are not bundled through unofficial mirrors; an authorized
HTTPS RSS URL can be added by its license holder.

## Universal share cards

Every aircraft, vessel, boat, event, headline, market record, airport, runway, port,
camera, radio station, television stream, space-weather item, infrastructure item and
frequency reference has a visible `SHARE CARD` action. The selected-object detail panel and
wire cards expose the same action. Weather frames, country-watch scores, analyst watches,
source-registry rows, intelligence metrics, regional density rows, proximity watches and
correlation cards also have direct sharing controls. Every page has a visible
`SHARE THIS PAGE AS CARD` action for its current filtered summary.

Sharing creates a local 1080 × 1350 PNG branded `DU WORLD MONITOR` and opens the
native Android share sheet. The image shows status, credibility, severity, category, region,
summary, key facts, named source, UTC timestamp and coordinates where available. The complete
fact set and original source URL are included as share text when more detail exists than can
safely fit on the image. Cards retain `RAW`, `CALCULATED`, `UNVERIFIED`, `REPORTED`, `CONFIRMED` and
`PUBLIC SOURCE` distinctions and carry an appropriate verification disclaimer.

The catalog always says `provider-returned records`; no open feed can truthfully expose
every aircraft, vessel, station or camera in the world. Stream rights, delay, coverage,
geo-restrictions and uptime remain under each publisher's control.

## Intelligence brief and credibility

`INTEL` opens a full-screen brief calculated from currently loaded records. It shows layer
coverage, provider health, priority signals, regional observed-signal density, 12-hour
movement in provider record counts, cross-domain proximity watches and possible cross-source
correlations. A proximity watch compares a mapped event coordinate with aircraft fixes
within 500 km/20 minutes and vessel fixes within 300 km/45 minutes. It never claims those
objects caused, joined or verified the event. Cross-source correlation still requires
independent publishers plus location or headline similarity inside a 12-hour window. Both
tools are discovery aids only: neither upgrades an event's credibility or predicts an event.

The wire desk now has an explicit `1H`, `6H`, `24H` or `72H` recency window in addition to
type, region and severity filters. The selected window also appears in the moving telemetry
strip so an analyst can see the active scope at a glance.

- `RAW SIGNAL` — machine telemetry; not a reported story.
- `CALCULATED` — derived from named public elements; not live telemetry.
- `UNVERIFIED — DEVELOPING` — a fast headline signal without corroboration.
- `REPORTED` — publisher-reported material.
- `CONFIRMED — OFFICIAL SOURCE` — structured official USGS, NASA or NOAA data.
- `PUBLIC SOURCE — AVAILABILITY VARIES` — a directory or reference record, not an incident.

Urgency and credibility are separate. Green means online/normal, amber means developing,
cached or syncing, and red means a severity 4–5 priority signal or source fault. Every event
shows its source and UTC timestamp; the UI never converts an unverified item into confirmed
fact merely because it is urgent.

## Providers and refresh budgets

Keyless sources include OpenSky, RainViewer, USGS, NASA EONET, NOAA SWPC, NOAA Aviation
Weather Center, CelesTrak GP, GDELT DOC,
the newest bounded GDELT GKG archive, OurAirports, Frankfurter reference FX, configured RSS,
Radio Browser and IPTV-org. Optional AISStream, Windy Webcams, CoinGecko Demo and OpenSky OAuth
credentials are entered on-device and encrypted with Android Keystore; no API key is
compiled into the APK.

OpenSky global anonymous refreshes are deliberately conservative because its current API
uses daily request credits. Detailed map sectors cost fewer credits and refresh faster.
Authenticated sectors can refresh every 30 seconds. Weather, event, news, directory and
space-weather feeds each use separate cache windows and retry schedules. Last-good data
stays visible with a cached/offline label if a provider cannot be reached. Repeated failures
use provider-specific exponential backoff with bounded jitter, preventing one unreachable
free source from creating a request storm or blocking another layer.

AISStream uses a native RFC 6455 TLS WebSocket and updates its subscription to the visible
map bounds. For a broadly distributed public product, place secret-bearing providers behind
your own backend; direct on-device credentials are intended for personal sideload use.

## Build and distribution

R24 uses Java 17, Android Gradle Plugin 8.11.1, Gradle 8.13, compile SDK 36, target SDK 35
and minimum Android 6.0 (API 23). The build has no external runtime dependencies.

The included GitHub Actions workflow restores this complete source tree, rejects WebView or
site-wrapper code, runs Android lint, compiles the project, verifies the package manifest and
signature, and uploads one installable APK named:

`du-world-moniter-R24-4D-Fusion.apk`

The workflow produces an APK artifact only. It does not deploy GitHub Pages or a website.
