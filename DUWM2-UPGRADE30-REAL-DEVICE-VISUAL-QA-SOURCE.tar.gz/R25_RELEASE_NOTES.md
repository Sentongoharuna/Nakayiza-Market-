# du-world moniter R25 — Advanced Home Intelligence

R25 adds eight native, independently resizable Android home-screen widgets while preserving
the standalone native application introduced in earlier releases. No WebView, hosted dashboard,
or synthetic activity feed is used.

## Widget suite

1. **DU Alert Beacon (1×1)** — priority count, severity state, source freshness.
2. **DU Live Counters (2×1)** — provider-returned air, sea, event, orbit, media, and weather state.
3. **DU Local Watch (2×2)** — per-instance region/radius watch, local counts, newest matching signal.
4. **DU Breaking Wire (4×1)** — newest-first headline, credibility, source, timestamp, previous/next.
5. **DU Air & Sea Tracker (4×2)** — aircraft/vessel readouts, speed, course, altitude/destination.
6. **DU Hazards & Weather (4×2)** — natural events, SIGMETs, space weather, and radar health.
7. **DU Media Watch (4×2)** — public camera/radio/TV directory availability and safe app deep links.
8. **DU Command Centre (4×4)** — UTC/local clocks, responsive globe snapshot, counts, health, top events.

Every instance can use a different label, region, minimum event severity, and optional broad
distance lens derived from the device timezone. The app requests no GPS permission. Source and
acquisition age are mandatory credibility safeguards and cannot be hidden.

## R25 next upgrade: Home Intelligence Mission Deck

The main app now has a visible **WIDGETS** mission page. It explains each widget, its intended
size, its data contract and limitations, offers one-tap pin requests on supported launchers, and
provides an explicit refresh command. Tapping a widget deep-links to the matching native live page.

## Refresh and truth contract

- Foreground acquisitions update the shared widget cache immediately.
- The widget refresh button requests a bounded 27-second acquisition window.
- Periodic work targets Android's 15-minute minimum and is network-aware; Android or the launcher
  may defer it for battery policy.
- Widgets show snapshots, not fake continuous animation. The command widget renders a capped
  source-attributed globe image to avoid launcher/Binder memory failures.
- `UNVERIFIED`, `REPORTED`, `CONFIRMED`, `RAW SIGNAL`, `CALCULATED`, and `PUBLIC SOURCE` remain
  distinct. Urgency never silently upgrades credibility.
- Counts represent records returned by configured providers, not complete world coverage.
- AISStream vessels and Windy webcams still require the user's own provider keys.

## Build identity

- Package: `com.sentongoharuna.worldsituationroom`
- Version code: `28`
- Version name: `25.0-2026-home-intelligence`
- Minimum Android: API 23 / Android 6.0
- Compile SDK: 36
- Target SDK: 35
