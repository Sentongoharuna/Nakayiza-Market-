# DU World Monitor R30 — Local Monitors API contract

R30 is local-first. Recording, importing, watching, drafting, profile editing, likes and comments
remain usable without a server. Cross-device feeds and true live publishing are enabled only when
the user connects a public HTTPS endpoint in **Local Monitors → Profile → Monitor Network**.

The app sends `Authorization: Bearer <account token>` when configured and an optional
`X-DU-Live-Token` for live-session creation. Redirects are refused so credentials are never
forwarded to another host. JSON responses are capped at 4 MiB. Uploaded videos are capped locally
at 768 MiB.

## Required endpoints

### `GET /v1/reports?limit=40&filter=FOR_YOU|LIVE|NEARBY|FOLLOWING&region=<text>`

Return either a JSON array or `{ "reports": [...] }`. Each report should include:

- `id`, `profile_id`, `display_name`, `handle`, optional HTTPS `avatar_url`
- `location_name`, optional `latitude` and `longitude`
- `caption`, `category`, `created_at_ms`
- `video_url` and optional `share_url` using HTTPS
- `live`, `viewer_count`, `likes`, `comment_count`
- `truth_state`: `UNVERIFIED`, `REPORTED`, or `CONFIRMED`
- `profile_verified` (profile status only; it never confirms the report)

### `POST /v1/reports`

Accept `multipart/form-data` with a JSON part named `report` and an MP4 part named `video`.
Return `{ "report": { ... } }` or the report object. A new public report must not be promoted above
`UNVERIFIED` merely because it was uploaded, liked, or posted by a verified profile.

This endpoint is also the compatibility fallback when the service does not expose resumable
uploads. Failed fallback uploads restart from byte zero, but the private local video is retained.

### Resumable upload endpoints (recommended)

`POST /v1/uploads` accepts JSON containing `profile`, `report`, `file_size`, and `content_type`.
Return `{ "upload": { "id": "opaque-id", "offset": 0, "chunk_size": 1048576 } }`.

- `HEAD /v1/uploads/{uploadId}` returns the authoritative `Upload-Offset` header.
- `PUT /v1/uploads/{uploadId}` accepts `application/offset+octet-stream` and the headers
  `Upload-Offset` and `Upload-Length`; return the new `Upload-Offset`.
- `POST /v1/uploads/{uploadId}/complete` accepts the profile/report JSON and returns the
  published report object.

Upload IDs are persisted locally so an interrupted transfer can resume after reopening the app.
The client permits only the configured HTTPS Monitor Network origin for these requests.

### `GET /v1/reports/{reportId}/comments?limit=100`

Return a JSON array or `{ "comments": [...] }`. A comment includes `id`, `profile_id`,
`display_name`, `handle`, `body`, and `created_at_ms`.

### Interaction endpoints

- `POST /v1/reports/{reportId}/comments`
- `POST /v1/reports/{reportId}/like`
- `POST /v1/profiles/{profileId}/follow`
- `POST /v1/reports/{reportId}/flag`

The request bodies are small JSON documents containing the acting profile ID and the requested
state or content. Enforce authentication, per-account rate limits, idempotency and abuse review on
the service.

### `POST /v1/live/sessions`

Create a short-lived publishing session. Return:

```json
{
  "session": {
    "id": "opaque-session-id",
    "report_id": "public-report-id",
    "publisher_url": "https://publisher.example/session",
    "playback_url": "https://media.example/live/playlist.m3u8",
    "expires_at_ms": 1790000000000
  }
}
```

Both URLs must be HTTPS. The publisher URL opens in a capable broadcasting surface selected by
Android; the playback URL is watched natively in DU World Monitor. The client never relabels a
recorded clip as live when this session cannot be created.

## Service obligations

The service must implement account authentication, consent records, deletion, privacy controls,
copyright complaints, reporting/blocking, moderation, child-safety controls, live-stream shutdown,
retention rules, encrypted transport, rate limits and regional legal compliance. Strip unsafe
metadata, virus-scan uploads, transcode into bounded playback formats, preserve the original
capture time separately, and log every credibility-state change with the named reviewer/source.
Reporter avatar hosting must return bounded HTTPS image URLs. R30 keeps locally selected profile
photos on the phone unless the connected account service explicitly uploads and returns one.

Every new public report continues to begin as **UNVERIFIED**. R30 also keeps crash references and
safe-mode state only on the phone; the API must not request or depend on those local diagnostics.
