#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuSpatialState.java DuTrackActivity.java DuContactsActivity.java DuCockpitActivity.java DuSensorActivity.java DuDetectionActivity.java DuAskActivity.java DuGlobalContextActivity.java DuSceneDirectorActivity.java;do test -s "$J/$f";done
grep -F '"TRACK"' "$J/DuContextBar.java" >/dev/null
grep -F '"ASK DUWM"' "$J/Du2More.java" >/dev/null
echo "DUWM2 SPATIAL INTELLIGENCE PASS"
