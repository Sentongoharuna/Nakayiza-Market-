#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
test -s "$J/DuWorldWallpaperService.java";test -s "$P/app/src/main/res/xml/du_world_wallpaper.xml"
grep -F 'extends WallpaperService' "$J/DuWorldWallpaperService.java" >/dev/null
grep -F 'new DuLiveRepository' "$J/DuWorldWallpaperService.java" >/dev/null
grep -F 'new DuLiveCounts' "$J/DuWorldWallpaperService.java" >/dev/null
grep -F 'repo.signals("AIR")' "$J/DuWorldWallpaperService.java" >/dev/null
grep -F 'repo.signals("SEA")' "$J/DuWorldWallpaperService.java" >/dev/null
grep -F 'DuWorldWallpaperService' "$M" >/dev/null
grep -F 'android.permission.BIND_WALLPAPER' "$M" >/dev/null
grep -F 'ACTION_CHANGE_LIVE_WALLPAPER' "$J/DuWallpaperPageActivity.java" >/dev/null
echo "DUWM2 LIVE WALLPAPER PASS"
