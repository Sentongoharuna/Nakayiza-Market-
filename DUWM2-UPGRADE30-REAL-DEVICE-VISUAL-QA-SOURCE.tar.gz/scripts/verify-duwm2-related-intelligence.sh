#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuRelatedEngine.java DuMonitorRelations.java DuRelatedPanel.java DuRelatedActivity.java;do test -s "$J/$f";done
grep -F 'DuProximityEngine.distance' "$J/DuRelatedEngine.java" >/dev/null
grep -F 'entity/topic overlap' "$J/DuRelatedEngine.java" >/dev/null
grep -F 'cross-domain' "$J/DuRelatedEngine.java" >/dev/null
grep -F 'new MonitorStore(c).reports()' "$J/DuMonitorRelations.java" >/dev/null
grep -F 'DuRelatedPanel.make(this,fs,fi)' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuSignalIntent.detail(a,r.signal)' "$J/DuRelatedPanel.java" >/dev/null
grep -F 'DuMonitorPlayer.open(a,m.id)' "$J/DuRelatedPanel.java" >/dev/null
grep -F 'DuRelatedActivity' "$M" >/dev/null
echo "DUWM2 RELATED INTELLIGENCE PASS"
