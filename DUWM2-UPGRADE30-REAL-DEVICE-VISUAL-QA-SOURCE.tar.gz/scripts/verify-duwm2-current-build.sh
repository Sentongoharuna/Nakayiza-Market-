#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
M="$P/app/src/main/AndroidManifest.xml"

test -f "$P/app/build.gradle.kts"
test -f "$M"
test "$(grep -o 'android.intent.category.LAUNCHER' "$M" | wc -l)" -eq 1
grep -F 'android:name=".DuIntegratedHomeActivity"' "$M" >/dev/null

for f in \
 DuIntegratedHomeActivity.java DuPageRouter.java DuFlow.java DuObjectPayload.java \
 DuVisualEngine.java DuRecordDetailActivity.java DuSystemIndexActivity.java \
 DuMonitorHubActivity.java DuShareStudioActivity.java DuShareRenderer.java \
 DuGlobalSearchActivity.java DuWatchlistActivity.java DuSituationRoomActivity.java \
 DuProviderBridge.java DuProviderDiagnostics.java DuIntegrationStatusActivity.java
do
  test -s "$J/$f"
done

grep -R -F "LIVE SOURCE INDEX" "$J" >/dev/null
grep -R -F "SHARE THIS PAGE AS CARD" "$J" >/dev/null
grep -F 'GLOBE' "$J/Du2Nav.java" >/dev/null
grep -F 'NEWS' "$J/Du2Nav.java" >/dev/null
grep -F 'MONITORS' "$J/Du2Nav.java" >/dev/null
grep -F 'MORE' "$J/Du2Nav.java" >/dev/null
grep -F 'DuPageRouter.open' "$J/DuToolDirectoryActivity.java" >/dev/null
grep -F 'DuObjectPayload.from' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'FileProvider.getUriForFile' "$J/DuShareRenderer.java" >/dev/null
grep -F 'implementation("androidx.core:core:1.13.1")' "$P/app/build.gradle.kts" >/dev/null

echo "DUWM2 CURRENT INTEGRATED BUILD CONTRACT PASS"
