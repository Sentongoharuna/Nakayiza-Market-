#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuSignalIntent.java"
grep -F 'startActivity(DuSignalIntent.detail(MainActivity.this, signal))' "$J/MainActivity.java" >/dev/null
grep -F 'selectedSignal = signal' "$J/MainActivity.java" >/dev/null
grep -F 'DuSpatialState.select(MainActivity.this' "$J/MainActivity.java" >/dev/null
grep -F 'case FLIGHTS:return"AIR"' "$J/DuSignalIntent.java" >/dev/null
grep -F 'case SHIPS:return"SEA"' "$J/DuSignalIntent.java" >/dev/null
grep -F 'case SATELLITES:return"ORBIT"' "$J/DuSignalIntent.java" >/dev/null
grep -F 'EXACT PROVIDER OBJECT' "$J/DuRecordDetailActivity.java" >/dev/null
echo "DUWM2 EXACT GLOBE MARKER DETAIL PASS"
