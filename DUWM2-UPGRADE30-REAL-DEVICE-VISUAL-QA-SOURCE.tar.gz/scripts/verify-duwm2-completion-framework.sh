#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuProviderBridge.java DuProviderDiagnostics.java DuGlobalSearchActivity.java DuWatchlist.java DuWatchlistActivity.java DuOnboardingActivity.java DuA11y.java DuNavigationMatrixActivity.java;do test -s "$J/$f";done
grep -F 'WATCH' "$J/DuContextBar.java" >/dev/null
grep -F 'SEARCH' "$J/Du2More.java" >/dev/null
grep -F 'WATCHLIST' "$J/Du2More.java" >/dev/null
grep -F 'NAV QA' "$J/Du2More.java" >/dev/null
grep -F 'DuProviderDiagnostics.summary' "$J/DuSourceHealthPageActivity.java" >/dev/null
test -s "$P/docs/DUWM2-COMPLETION-MATRIX.md"
echo "DUWM2 COMPLETION FRAMEWORK PASS"
