#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuProviderHealthStore.java DuProviderDiagnosticView.java;do test -s "$J/$f";done
grep -F 'DuProviderHealthStore.record(this, layer, status)' "$J/MainActivity.java" >/dev/null
grep -F 'DuProviderHealthStore.record(this, Signal.Layer.WEATHER, status)' "$J/MainActivity.java" >/dev/null
grep -F 's.state==FeedStatus.State.OFFLINE' "$J/DuProviderHealthStore.java" >/dev/null
grep -F '"LAST SUCCESS"' "$J/DuProviderDiagnosticView.java" >/dev/null
grep -F '"LAST FAILURE"' "$J/DuProviderDiagnosticView.java" >/dev/null
grep -F 'Provider message:' "$J/DuProviderDiagnosticView.java" >/dev/null
grep -F 'DuProviderDiagnosticView.make' "$J/DuSourceHealthPageActivity.java" >/dev/null
echo "DUWM2 PROVIDER DIAGNOSTICS PASS"
