#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
M="$P/app/src/main/AndroidManifest.xml"

# Core source and AndroidX/FileProvider contracts.
grep -Fx 'android.useAndroidX=true' "$P/gradle.properties" >/dev/null
grep -Fx 'org.gradle.configuration-cache=false' "$P/gradle.properties" >/dev/null
grep -F 'androidx.core:core:1.13.1' "$P/app/build.gradle.kts" >/dev/null
grep -F 'androidx.core.content.FileProvider' "$M" >/dev/null
test -s "$P/app/src/main/res/xml/du_file_paths.xml"

# Single launcher and all explicit manifest Activity classes must exist.
test "$(grep -o 'android.intent.category.LAUNCHER' "$M" | wc -l)" -eq 1
python3 - "$P" <<'PY'
import re,sys,pathlib
p=pathlib.Path(sys.argv[1])
j=p/"app/src/main/java/com/sentongoharuna/worldsituationroom"
m=(p/"app/src/main/AndroidManifest.xml").read_text()
missing=[]
for c in re.findall(r'android:name="\.([A-Za-z0-9_]+)"',m):
    if c.endswith("Activity") and not (j/(c+".java")).exists():
        missing.append(c)
if missing:
    raise SystemExit("Missing manifest activity source: "+", ".join(sorted(set(missing))))
PY

# Every generated internal Activity class referenced as X.class must have a source file.
python3 - "$J" <<'PY'
import re,sys,pathlib
j=pathlib.Path(sys.argv[1]); missing=set()
for f in j.glob("Du*.java"):
    t=f.read_text(errors="ignore")
    for c in re.findall(r'\b(Du[A-Za-z0-9_]*Activity)\.class\b',t):
        if not (j/(c+".java")).exists(): missing.add(c)
if missing: raise SystemExit("Missing referenced activity source: "+", ".join(sorted(missing)))
PY

# UI constants referenced by Du*.java must be defined in Du2Ui.
python3 - "$J" <<'PY'
import re,sys,pathlib
j=pathlib.Path(sys.argv[1]); ui=(j/"Du2Ui.java").read_text()
refs=set()
for f in j.glob("Du*.java"):
    refs.update(re.findall(r'Du2Ui\.([A-Z][A-Z0-9_]*)',f.read_text(errors="ignore")))
defs=set(re.findall(r'\b([A-Z][A-Z0-9_]*)\s*=',ui))
missing=sorted(refs-defs)
if missing: raise SystemExit("Undefined Du2Ui constants: "+", ".join(missing))
PY

# No obsolete SDK installer and no configuration cache.
echo "DUWM2 FIX5 PREFLIGHT PASS"
