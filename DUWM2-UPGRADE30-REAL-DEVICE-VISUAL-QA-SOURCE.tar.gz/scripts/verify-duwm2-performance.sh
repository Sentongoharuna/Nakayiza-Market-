#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuPerformancePolicy.java DuRenderBudget.java DuPerformanceActivity.java;do test -s "$J/$f";done
grep -F 'DuPerformancePolicy.hudBudget(getContext())' "$J/SatelliteMapView.java" >/dev/null
grep -F 'DuPerformancePolicy.imageWorkers(c)' "$J/DuRemoteImageLoader.java" >/dev/null
grep -F 'DuPerformancePolicy.imageCacheBytes(c)' "$J/DuRemoteImageLoader.java" >/dev/null
grep -F 'mem.evictAll()' "$J/DuRemoteImageLoader.java" >/dev/null
grep -F 'DuPerformancePolicy.wallpaperFrameMs' "$J/DuWorldWallpaperService.java" >/dev/null
grep -F 'DuPerformancePolicy.lowMemory(this)?40:80' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F '"PERFORMANCE"' "$J/Du2More.java" >/dev/null
echo "DUWM2 PERFORMANCE ENGINEERING PASS"
