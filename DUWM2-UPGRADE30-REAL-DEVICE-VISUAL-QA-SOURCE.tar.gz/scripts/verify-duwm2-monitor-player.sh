#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuMonitorPlayerActivity.java DuVideoThumbnail.java DuMonitorPlayer.java StoryVideoView.java;do test -s "$J/$f";done
grep -F 'SeekBar' "$J/DuMonitorPlayerActivity.java" >/dev/null
grep -F '"PLAY/PAUSE","MUTE","FULLSCREEN","FIT/FILL"' "$J/DuMonitorPlayerActivity.java" >/dev/null
grep -F 'video.seekTo' "$J/DuMonitorPlayerActivity.java" >/dev/null
grep -F 'setMuted' "$J/DuMonitorPlayerActivity.java" >/dev/null
grep -F 'getFrameAtTime' "$J/DuVideoThumbnail.java" >/dev/null
grep -F 'putExtra("report_id",id)' "$J/DuMonitorPlayer.java" >/dev/null
grep -F 'PLAY REPORT' "$J/DuMonitorHubActivity.java" >/dev/null
grep -F 'DuMonitorPlayerActivity' "$M" >/dev/null
echo "DUWM2 MONITOR VIDEO PLAYER PASS"
