#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
test -s "$J/DuMiniMapView.java"
grep -F 'DuTrackHistoryStore.load' "$J/DuMiniMapView.java" >/dev/null
grep -F 'drawLine(px,py,x,y,p)' "$J/DuMiniMapView.java" >/dev/null
grep -F 'c.drawCircle(cx,cy' "$J/DuMiniMapView.java" >/dev/null
grep -F 'repo' "$J/DuGeoPreview.java" >/dev/null || true
grep -F 'DuMiniMapView map=new DuMiniMapView' "$J/DuGeoPreview.java" >/dev/null
grep -F 'map.setPosition(s.latitude,s.longitude)' "$J/DuGeoPreview.java" >/dev/null
grep -F 'DuMiniMapView mini=new DuMiniMapView' "$J/DuProviderRecordView.java" >/dev/null
echo "DUWM2 REAL MINI MAPS PASS"
