#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuUiMotion.java DuContextBar.java DuIntelligenceSheet.java DuDisplayModeActivity.java;do test -s "$J/$f";done
grep -F 'LIVE WORLD GLOBE' "$J/DuGlobeCommandActivity.java" >/dev/null
grep -F 'INTELLIGENCE' "$J/DuIntelligenceSheet.java" >/dev/null
grep -F 'DETAIL","SOURCE","MAP","FOLLOW","SHARE' "$J/DuContextBar.java" >/dev/null
grep -F 'STORY","MAP","COMPACT","MONITOR' "$J/DuShareStudioActivity.java" >/dev/null
grep -F 'DISPLAY' "$J/Du2More.java" >/dev/null
grep -R -F 'LIVE SOURCE INDEX' "$J" >/dev/null
echo "DUWM2 INTERFACE MAX PASS"
