#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuVisualEngine.java DuGeoPreview.java DuSelectionState.java DuSituationRoomActivity.java;do test -s "$J/$f";done
grep -F 'TRACK · HEADING · ALTITUDE · SPEED' "$J/DuVisualEngine.java" >/dev/null
grep -F 'VESSEL · HEADING · ROUTE' "$J/DuVisualEngine.java" >/dev/null
grep -F 'CONDITION · WIND · PRESSURE' "$J/DuVisualEngine.java" >/dev/null
grep -F 'SATELLITE · TRACK · PASS' "$J/DuVisualEngine.java" >/dev/null
grep -F 'DuSelectionState.set' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuGeoPreview.make' "$J/DuRecordDetailActivity.java" >/dev/null
grep -F 'DuSituationRoomActivity.class' "$J/DuPageRouter.java" >/dev/null
echo "DUWM2 VISUAL DATA ENGINE PASS"
