#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuRemoteImageLoader.java DuImageResolver.java DuRemoteImageCard.java MonitorAvatarLoader.java;do test -s "$J/$f";done
grep -F 'LruCache<String,Bitmap>' "$J/DuRemoteImageLoader.java" >/dev/null
grep -F 'duwm-images-v1' "$J/DuRemoteImageLoader.java" >/dev/null
grep -F 'LOADING' "$J/DuRemoteImageLoader.java" >/dev/null
grep -F 'IMAGE UNAVAILABLE' "$J/DuRemoteImageLoader.java" >/dev/null
grep -F 'startsWith("https://")' "$J/DuImageResolver.java" >/dev/null
grep -F 'DuRemoteImageCard.make' "$J/DuProviderRecordView.java" >/dev/null
grep -F 'monitor-avatars' "$J/MonitorAvatarLoader.java" >/dev/null
echo "DUWM2 REMOTE IMAGE CACHE PASS"
