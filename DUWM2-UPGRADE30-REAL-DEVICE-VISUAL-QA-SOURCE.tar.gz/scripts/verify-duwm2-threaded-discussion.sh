#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom";M="$P/app/src/main/AndroidManifest.xml"
for f in DuThreadStore.java DuDiscussionActivity.java DuDiscussion.java;do test -s "$J/$f";done
grep -F 'store.comments(reportId)' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'DuThreadStore.parent' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'api.loadComments' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'api.postComment' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'api.setLike' "$J/DuDiscussionActivity.java" >/dev/null
grep -F '"REPLY"' "$J/DuDiscussionActivity.java" >/dev/null
grep -F '"ACK"' "$J/DuDiscussionActivity.java" >/dev/null
grep -F 'DISCUSSION' "$J/DuMonitorHubActivity.java" >/dev/null
grep -F 'OPEN DISCUSSION' "$J/DuMonitorPlayerActivity.java" >/dev/null
grep -F 'DuDiscussionActivity' "$M" >/dev/null
echo "DUWM2 THREADED DISCUSSION PASS"
