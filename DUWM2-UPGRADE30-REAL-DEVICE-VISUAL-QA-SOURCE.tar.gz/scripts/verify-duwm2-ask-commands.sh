#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuCommandQuery.java DuCommandEngine.java DuAskActivity.java;do test -s "$J/$f";done
grep -F 'radiusKm' "$J/DuCommandQuery.java" >/dev/null
grep -F 'windowMs' "$J/DuCommandQuery.java" >/dev/null
grep -F 'repo.signals(q.system)' "$J/DuCommandEngine.java" >/dev/null
grep -F 'now-s.timestampMs>q.windowMs' "$J/DuCommandEngine.java" >/dev/null
grep -F 'DuSignalIntent.detail(this,s)' "$J/DuAskActivity.java" >/dev/null
grep -F 'DuSignalIntent.track(this,s)' "$J/DuAskActivity.java" >/dev/null
grep -F 'DUWM does not invent results' "$J/DuAskActivity.java" >/dev/null
echo "DUWM2 ASK COMMANDS PASS"
