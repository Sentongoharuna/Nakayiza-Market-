#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "$0")/.." && pwd)"
main="$project_dir/app/src/main/java/com/sentongoharuna/worldsituationroom"
manifest="$project_dir/app/src/main/AndroidManifest.xml"
gradle_file="$project_dir/app/build.gradle.kts"
apk="${1:-}"

EXPECTED_VERSION_CODE=32 \
EXPECTED_VERSION_NAME=29.0-2026-immersive-local-monitors \
  "$project_dir/scripts/verify-r27-live-motion-widgets.sh" "$apk"

for source in LocalMonitorActivity MonitorReport MonitorStore MonitorProfileStore \
  MonitorApiClient MonitorMediaProvider StoryVideoView MonitorAvatarLoader; do
  test -s "$main/$source.java"
done
test -s "$project_dir/LOCAL_MONITORS_API.md"
test -s "$project_dir/R29_RELEASE_NOTES.md"

grep -Fq 'versionCode = 32' "$gradle_file"
grep -Fq 'versionName = "29.0-2026-immersive-local-monitors"' "$gradle_file"
grep -Fq 'android:name=".LocalMonitorActivity"' "$manifest"
grep -Fq 'MediaStore.ACTION_VIDEO_CAPTURE' "$main/LocalMonitorActivity.java"
grep -Fq 'Intent.ACTION_OPEN_DOCUMENT' "$main/LocalMonitorActivity.java"
grep -Fq 'toggleFillMode()' "$main/LocalMonitorActivity.java"
grep -Fq 'navigateAnimated(vertical < 0 ? 1 : -1)' "$main/LocalMonitorActivity.java"
grep -Fq 'STATE_DRAFT = "DRAFT"' "$main/MonitorReport.java"
grep -Fq 'STATE_UPLOADING = "UPLOADING"' "$main/MonitorReport.java"
grep -Fq '/v1/uploads/' "$main/MonitorApiClient.java"
grep -Fq 'Upload-Offset' "$main/MonitorApiClient.java"
grep -Fq 'local-monitor:' "$main/MainActivity.java"
grep -Fq 'localMonitorSignals()' "$main/MainActivity.java"
grep -Fq 'BUILT-IN PLACE CENTROID / APPROXIMATE' "$main/MainActivity.java"
grep -Fq 'add("kampale", 0.3476, 32.5825, "AFRICA")' "$main/GeoIndex.java"
grep -Fq 'MAX_AVATAR_BYTES = 2 * 1024 * 1024' "$main/MonitorAvatarLoader.java"
grep -Fq 'Every new public report still begins as **UNVERIFIED**.' \
  "$project_dir/R29_RELEASE_NOTES.md"

if grep -REn 'android\.webkit\.WebView|<WebView|loadUrl\(' "$project_dir/app/src/main"; then
  echo 'R29 Local Monitors must remain native and cannot embed hosted pages.' >&2
  exit 1
fi

if grep -En '^[[:space:]]*(implementation|api)\(' "$gradle_file"; then
  echo 'R29 introduced a forbidden external runtime dependency.' >&2
  exit 1
fi

if test -n "$apk"; then
  sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  build_tools="$(find "$sdk_root/build-tools" -mindepth 1 -maxdepth 1 -type d \
    | sort -V | tail -n 1)"
  manifest_dump="$("$build_tools/aapt2" dump xmltree "$apk" --file AndroidManifest.xml)"
  grep -Fq 'LocalMonitorActivity' <<<"$manifest_dump"
  grep -Fq 'MonitorMediaProvider' <<<"$manifest_dump"

  inspect_dir="$(mktemp -d)"
  trap 'test -d "$inspect_dir" && rm -rf -- "$inspect_dir"' EXIT
  unzip -q "$apk" 'classes*.dex' -d "$inspect_dir"
  dex_dump="$({ for dex in "$inspect_dir"/classes*.dex; do "$build_tools/dexdump" -f "$dex"; done; })"
  for component in LocalMonitorActivity MonitorReport MonitorStore MonitorProfileStore \
    MonitorApiClient MonitorMediaProvider StoryVideoView MonitorAvatarLoader; do
    grep -Fq "/$component;" <<<"$dex_dump"
  done
fi

echo 'R29 IMMERSIVE LOCAL MONITORS PASS: full-screen stories + drafts + avatars + resumable uploads + globe markers'
