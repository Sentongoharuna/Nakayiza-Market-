#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
for f in DuLiveRepository.java DuProviderRecordView.java;do test -s "$J/$f";done
grep -F 'OperationsSnapshotStore' "$J/DuLiveRepository.java" >/dev/null
grep -F 'repo.signals(sys)' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'DuProviderRecordView.make' "$J/DuSystemIndexActivity.java" >/dev/null
grep -F 'repo.count(s)' "$J/DuProviderBridge.java" >/dev/null
! grep -F 'REC-1' "$J/DuSystemIndexActivity.java" >/dev/null
echo "DUWM2 REAL PROVIDER BINDING PASS"
