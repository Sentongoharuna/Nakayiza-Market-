#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}";J="$P/app/src/main/java/com/sentongoharuna/worldsituationroom"
grep -F 'R.drawable.du_brand_mark' "$J/DuShareRenderer.java" >/dev/null
grep -F 'if("MAP".equals(m))map' "$J/DuShareRenderer.java" >/dev/null
grep -F 'else if("COMPACT".equals(m))compact' "$J/DuShareRenderer.java" >/dev/null
grep -F 'else if("MONITOR".equals(m))monitor' "$J/DuShareRenderer.java" >/dev/null
grep -F 'else story' "$J/DuShareRenderer.java" >/dev/null
grep -F 'DuTrackHistoryStore.load(a,q.id)' "$J/DuShareRenderer.java" >/dev/null
grep -F 'NO SOURCE COORDINATES' "$J/DuShareRenderer.java" >/dev/null
grep -F 'FileProvider.getUriForFile' "$J/DuShareRenderer.java" >/dev/null
echo "DUWM2 GRAPHICAL SHARE LAYOUTS PASS"
