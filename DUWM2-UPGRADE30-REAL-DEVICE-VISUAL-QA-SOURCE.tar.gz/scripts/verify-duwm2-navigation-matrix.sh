#!/usr/bin/env bash
set -euo pipefail
P="${1:-.}"
python3 "$P/scripts/verify-duwm2-navigation-matrix.py" "$P"
grep -F '"NAV MATRIX"' "$P/app/src/main/java/com/sentongoharuna/worldsituationroom/Du2More.java" >/dev/null
echo "DUWM2 NAVIGATION UI PASS"
